import React from 'react';
import {CH1} from '../shots/ch1';
import {CH2} from '../shots/ch2';
import {CH3} from '../shots/ch3';
import {CH4} from '../shots/ch4';
import {CH5} from '../shots/ch5';
import {CH6} from '../shots/ch6';
import {CH7} from '../shots/ch7';
import {CH8} from '../shots/ch8';

export interface Chapter {
  id: string;
  title: string;
  subtitle: string;
  /**
   * Index into `phrases` in timing.json where this chapter begins.
   * ⚠️ These boundaries were ESTIMATED from the pause structure of the audio
   * (the narration text was not available). Open the film in `npm run studio`,
   * scrub to where each chapter really starts, and change the index (or use
   * `startSecond` to override with an exact time in seconds).
   */
  startPhrase: number;
  startSecond?: number;
  shots: React.FC[];
}

export const CHAPTERS: Chapter[] = [
  {id: 'hook', title: 'The Hook', subtitle: "NVIDIA's global impact", startPhrase: 0, shots: CH1},
  {id: 'childhood', title: 'Childhood & Education', subtitle: 'From Taiwan to America', startPhrase: 7, shots: CH2},
  {id: 'founding', title: 'The Founding', subtitle: 'Three co-founders and a big idea', startPhrase: 20, shots: CH3},
  {id: 'nv1', title: 'The NV1 Failure', subtitle: 'Surviving the early years', startPhrase: 35, shots: CH4},
  {id: 'riva', title: 'RIVA 128', subtitle: 'The comeback', startPhrase: 49, shots: CH5},
  {id: 'gpu', title: 'GeForce, CUDA & AlexNet', subtitle: 'The GPU becomes a supercomputer', startPhrase: 58, shots: CH6},
  {id: 'ai', title: 'The AI Revolution', subtitle: 'NVIDIA changes the world', startPhrase: 68, shots: CH7},
  {id: 'lesson', title: 'The Bigger Lesson', subtitle: 'What the journey teaches', startPhrase: 79, shots: CH8},
];
