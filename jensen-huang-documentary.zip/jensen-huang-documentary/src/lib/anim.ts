import {Easing, interpolate} from 'remotion';

export const clamp01 = (n: number) => Math.max(0, Math.min(1, n));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeInOut = Easing.bezier(0.4, 0, 0.2, 1);
export const easeOut = Easing.out(Easing.cubic);
export const backOut = Easing.out(Easing.back(1.9));

/** Clamped tween of `frame` from [f0,f1] to [a,b]. */
export const tween = (
  frame: number,
  f0: number,
  f1: number,
  a: number,
  b: number,
  easing: (t: number) => number = easeOut,
) =>
  interpolate(frame, [f0, f1], [a, b], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

/** 0 -> 1 with overshoot, starting at `start`. Great for pop-in props. */
export const pop = (frame: number, start: number, dur = 10) => {
  const t = clamp01((frame - start) / dur);
  return t <= 0 ? 0 : backOut(t);
};

export const wob = (frame: number, speed: number, amp: number, phase = 0) =>
  Math.sin(frame * speed + phase) * amp;

/** Deterministic pseudo random in [0,1). */
export const rand = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
