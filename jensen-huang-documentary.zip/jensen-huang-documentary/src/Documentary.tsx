import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {H, W} from './theme';
import {CHAPTERS} from './data/chapters';
import {CHAPTER_PLAN, PLAN, TOTAL_FRAMES} from './timeline';
import {ShotCtx} from './components/context';
import {Camera} from './components/Camera';
import {ChapterCard, FadeInOut, Vignette} from './components/Overlays';
import {useP} from './components/context';

const ShotView: React.FC<{Comp: React.FC; k: number; v: number}> = ({Comp, k, v}) => {
  const {p} = useP();
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', inset: 0}}>
      <Camera k={k} v={v} p={p}>
        <Comp />
      </Camera>
    </svg>
  );
};

export const Documentary: React.FC = () => (
  <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
    {/* The approved narration, untouched, plays for the entire film. */}
    <Audio src={staticFile('narration.wav')} />

    {PLAN.map((s, i) => (
      <Sequence key={i} from={s.from} durationInFrames={s.dur} name={`${CHAPTERS[s.chapter].id} #${s.k}`}>
        <ShotCtx.Provider value={{dur: s.dur, from: s.from, k: s.k, v: s.v}}>
          <ShotView Comp={s.Comp} k={s.k} v={s.v} />
        </ShotCtx.Provider>
      </Sequence>
    ))}

    <Vignette />

    {CHAPTER_PLAN.map((c) => (
      <Sequence key={c.index} from={c.from} durationInFrames={96} name={`title: ${CHAPTERS[c.index].title}`}>
        <ChapterCard index={c.index} title={CHAPTERS[c.index].title} subtitle={CHAPTERS[c.index].subtitle} wipe={c.index > 0} />
      </Sequence>
    ))}

    <FadeInOut total={TOTAL_FRAMES} />
  </AbsoluteFill>
);
