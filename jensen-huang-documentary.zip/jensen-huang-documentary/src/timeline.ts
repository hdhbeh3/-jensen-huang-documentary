import React from 'react';
import timing from './data/timing.json';
import {CHAPTERS} from './data/chapters';

export const FPS = timing.fps;
export const TOTAL_FRAMES = timing.durationInFrames;

/** Target length of one shot. Cuts always land on a real pause in the narration;
 *  long phrases are split evenly into shots of roughly this many seconds. */
export const TARGET_SHOT_SECONDS = 2.6;
export const MIN_SHOT_FRAMES = 30;

export interface ShotPlan {
  from: number;
  dur: number;
  chapter: number;
  k: number; // shot counter inside the chapter
  v: number; // how many times this template has already been used
  Comp: React.FC;
}

export interface ChapterPlan {
  index: number;
  from: number;
  to: number;
}

const phrases = timing.phrases as {start: number; end: number}[];

export const CHAPTER_PLAN: ChapterPlan[] = CHAPTERS.map((c, i) => {
  const startSec = c.startSecond ?? phrases[Math.min(c.startPhrase, phrases.length - 1)].start;
  const from = i === 0 ? 0 : Math.round(startSec * FPS);
  return {index: i, from, to: 0};
});
CHAPTER_PLAN.forEach((c, i) => {
  c.to = i === CHAPTER_PLAN.length - 1 ? TOTAL_FRAMES : CHAPTER_PLAN[i + 1].from;
});

export const buildPlan = (): ShotPlan[] => {
  const plan: ShotPlan[] = [];
  CHAPTER_PLAN.forEach((ch) => {
    const lib = CHAPTERS[ch.index].shots;
    // natural cut points: phrase starts that fall inside the chapter
    const cuts = [ch.from];
    phrases.forEach((ph) => {
      const fr = Math.round(ph.start * FPS);
      if (fr > ch.from + MIN_SHOT_FRAMES && fr < ch.to - MIN_SHOT_FRAMES) cuts.push(fr);
    });
    cuts.push(ch.to);
    let k = 0;
    for (let i = 0; i < cuts.length - 1; i++) {
      const a = cuts[i], b = cuts[i + 1];
      const n = Math.max(1, Math.round((b - a) / (TARGET_SHOT_SECONDS * FPS)));
      for (let j = 0; j < n; j++) {
        const s = a + Math.round(((b - a) * j) / n);
        const e = a + Math.round(((b - a) * (j + 1)) / n);
        plan.push({from: s, dur: e - s, chapter: ch.index, k, v: Math.floor(k / lib.length), Comp: lib[k % lib.length]});
        k++;
      }
    }
  });
  return plan;
};

export const PLAN = buildPlan();
