// Character "looks": every person in the film is the same Stickman rig with a
// different Look. Jensen has one look per life stage, all sharing hair + glasses.
export type HairStyle = 'side' | 'short' | 'curly' | 'bald' | 'bun' | 'long' | 'cap';
export type JacketType = 'leather' | 'blazer' | 'hoodie' | 'apron' | null;

export interface Look {
  skin: string;
  hair: string;
  hairStyle: HairStyle;
  glasses: boolean;
  top: string; // shirt colour
  bottom: string; // trousers colour
  jacket: JacketType;
  jacketColor: string;
  beard?: boolean;
  mustache?: boolean;
  headScale: number; // 1 = adult proportions
  height: number; // overall scale
  silver?: boolean; // grey streaks in hair
  shoe?: string;
}

const JENSEN_SKIN = '#e8b98d';
const JENSEN_HAIR = '#1b1a22';

export const LOOKS = {
  // ---- Jensen Huang through the years (always: side-swept black hair + glasses) ----
  jensenChild: {skin: JENSEN_SKIN, hair: JENSEN_HAIR, hairStyle: 'side', glasses: true, top: '#f4f1e8', bottom: '#3d5a9e', jacket: null, jacketColor: '#fff', headScale: 1.32, height: 0.62},
  jensenTeen: {skin: JENSEN_SKIN, hair: JENSEN_HAIR, hairStyle: 'side', glasses: true, top: '#c9d3ee', bottom: '#2b3563', jacket: 'hoodie', jacketColor: '#2a2d3a', headScale: 1.12, height: 0.86},
  jensenYoung: {skin: JENSEN_SKIN, hair: JENSEN_HAIR, hairStyle: 'side', glasses: true, top: '#f6f6f6', bottom: '#2a2d3d', jacket: 'blazer', jacketColor: '#2b2e3b', headScale: 1.0, height: 1.0},
  jensenCEO: {skin: JENSEN_SKIN, hair: '#26252d', hairStyle: 'side', glasses: true, top: '#2c2c34', bottom: '#1d2030', jacket: 'leather', jacketColor: '#17171c', headScale: 1.0, height: 1.0, silver: true},
  jensenWorker: {skin: JENSEN_SKIN, hair: JENSEN_HAIR, hairStyle: 'side', glasses: true, top: '#fff', bottom: '#3d3d4a', jacket: 'apron', jacketColor: '#c0392b', headScale: 1.12, height: 0.86},

  // ---- Family ----
  mom: {skin: JENSEN_SKIN, hair: '#1b1a22', hairStyle: 'bun', glasses: false, top: '#e26d8a', bottom: '#5a4b7a', jacket: null, jacketColor: '#fff', headScale: 1, height: 0.98},
  dad: {skin: JENSEN_SKIN, hair: '#1b1a22', hairStyle: 'short', glasses: false, top: '#6fa3d8', bottom: '#33384f', jacket: null, jacketColor: '#fff', headScale: 1, height: 1.05},

  // ---- Co-founders ----
  chris: {skin: '#f0c7a3', hair: '#5a3b24', hairStyle: 'short', glasses: false, top: '#3b82c4', bottom: '#2d3550', jacket: null, jacketColor: '#fff', headScale: 1, height: 1.08, beard: true},
  curtis: {skin: '#f2cba9', hair: '#8a5a2b', hairStyle: 'curly', glasses: false, top: '#4f9a6a', bottom: '#38405c', jacket: null, jacketColor: '#fff', headScale: 1, height: 1.0, mustache: true},

  // ---- Supporting cast ----
  teacher: {skin: '#d9a679', hair: '#3a2a22', hairStyle: 'bun', glasses: true, top: '#b86bd1', bottom: '#46405e', jacket: null, jacketColor: '#fff', headScale: 1, height: 1},
  student: {skin: '#f0c7a3', hair: '#7a4a2a', hairStyle: 'short', glasses: false, top: '#ff9f43', bottom: '#33405f', jacket: null, jacketColor: '#fff', headScale: 1.1, height: 0.9},
  student2: {skin: '#c68b5e', hair: '#1f1a1a', hairStyle: 'curly', glasses: true, top: '#7c5cff', bottom: '#2f3550', jacket: null, jacketColor: '#fff', headScale: 1.1, height: 0.92},
  gamer: {skin: '#e3b48a', hair: '#2d2d4a', hairStyle: 'cap', glasses: false, top: '#e5484d', bottom: '#2a2f48', jacket: 'hoodie', jacketColor: '#2c3a6e', headScale: 1.05, height: 0.95},
  gamer2: {skin: '#f0c7a3', hair: '#c08a3e', hairStyle: 'long', glasses: false, top: '#2dd4bf', bottom: '#2a2f48', jacket: null, jacketColor: '#fff', headScale: 1.05, height: 0.93},
  researcher: {skin: '#f2cba9', hair: '#2b2b2b', hairStyle: 'curly', glasses: true, top: '#ffffff', bottom: '#4a4f66', jacket: 'blazer', jacketColor: '#e9ecf5', headScale: 1, height: 1.02},
  professor: {skin: '#f0c7a3', hair: '#d9d9e3', hairStyle: 'bald', glasses: true, top: '#7a8bd1', bottom: '#3a3f5c', jacket: 'blazer', jacketColor: '#4b5b8c', headScale: 1, height: 1.03, beard: true},
  investor: {skin: '#f0c7a3', hair: '#9a9aa8', hairStyle: 'short', glasses: false, top: '#ffffff', bottom: '#22263a', jacket: 'blazer', jacketColor: '#3a3f5c', headScale: 1, height: 1.06},
  investor2: {skin: '#c68b5e', hair: '#222', hairStyle: 'bald', glasses: true, top: '#ffffff', bottom: '#22263a', jacket: 'blazer', jacketColor: '#6b3a3a', headScale: 1, height: 1.0, mustache: true},
  engineer: {skin: '#e3b48a', hair: '#3b2a20', hairStyle: 'short', glasses: true, top: '#59c2a0', bottom: '#2f3550', jacket: null, jacketColor: '#fff', headScale: 1, height: 1},
  engineer2: {skin: '#f0c7a3', hair: '#c0562a', hairStyle: 'long', glasses: false, top: '#ffb35c', bottom: '#2f3550', jacket: null, jacketColor: '#fff', headScale: 1, height: 0.97},
  fan: {skin: '#d9a679', hair: '#222', hairStyle: 'short', glasses: false, top: '#76b900', bottom: '#2a2f48', jacket: null, jacketColor: '#fff', headScale: 1.05, height: 0.95},
  fan2: {skin: '#f0c7a3', hair: '#5a3b24', hairStyle: 'bun', glasses: false, top: '#ff7aa2', bottom: '#2a2f48', jacket: null, jacketColor: '#fff', headScale: 1.05, height: 0.95},
  roommate: {skin: '#c68b5e', hair: '#1f1a1a', hairStyle: 'short', glasses: false, top: '#d9534f', bottom: '#2f3550', jacket: null, jacketColor: '#fff', headScale: 1.12, height: 0.88},
} satisfies Record<string, Look>;

export type LookName = keyof typeof LOOKS;
