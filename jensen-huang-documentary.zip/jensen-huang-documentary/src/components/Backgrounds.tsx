import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, OUT, W, H} from '../theme';
import {rand} from '../lib/anim';

/** Every background accepts `p` (shot progress 0..1) for parallax, and `tone`
 *  (0 day, 1 sunset, 2 night, 3 dawn) so repeated shots never look identical. */
export interface BgProps {
  p?: number;
  tone?: number;
}

const SKY: [string, string][] = [
  ['#7ec8ff', '#e4f6ff'],
  ['#ff8f6b', '#ffe2a0'],
  ['#0f1538', '#3b4182'],
  ['#9db4ff', '#ffd9c7'],
];
const tn = (t = 0) => ((t % 4) + 4) % 4;
const night = (t = 0) => tn(t) === 2;

const Defs: React.FC<{id: string; a: string; b: string}> = ({id, a, b}) => (
  <defs>
    <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor={a} />
      <stop offset="1" stopColor={b} />
    </linearGradient>
  </defs>
);

const Wash: React.FC<{id: string; a: string; b: string}> = ({id, a, b}) => (
  <>
    <Defs id={id} a={a} b={b} />
    <rect x={-300} y={-200} width={W + 600} height={H + 400} fill={`url(#${id})`} />
  </>
);

const Cloud: React.FC<{x: number; y: number; s?: number; o?: number}> = ({x, y, s = 1, o = 0.9}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o} fill="#fff">
    <ellipse cx={0} cy={0} rx={90} ry={34} />
    <ellipse cx={-50} cy={-18} rx={50} ry={38} />
    <ellipse cx={30} cy={-30} rx={56} ry={42} />
  </g>
);

export const Sky: React.FC<BgProps & {horizon?: number}> = ({p = 0, tone = 0}) => {
  const [a, b] = SKY[tn(tone)];
  const f = useCurrentFrame();
  return (
    <g>
      <Wash id={`sky${tone}`} a={a} b={b} />
      {night(tone) &&
        Array.from({length: 60}).map((_, i) => (
          <circle key={i} cx={rand(i) * 2200 - 150} cy={rand(i + 90) * 700} r={1.5 + rand(i + 3) * 2.2} fill="#fff" opacity={0.5 + 0.5 * Math.sin(f * 0.1 + i)} />
        ))}
      {night(tone) ? (
        <circle cx={1500 - p * 40} cy={200} r={70} fill="#fdf6d8" />
      ) : (
        <circle cx={1450 - p * 40} cy={tn(tone) === 1 ? 600 : 220} r={86} fill={tn(tone) === 1 ? '#ffb347' : '#fff3a0'} opacity={0.95} />
      )}
      {!night(tone) && (
        <>
          <Cloud x={300 + p * 90 + f * 0.2} y={200} s={1.2} />
          <Cloud x={1000 + p * 60 + f * 0.15} y={330} s={0.8} o={0.8} />
          <Cloud x={1600 - p * 70} y={150} s={1} o={0.7} />
        </>
      )}
    </g>
  );
};

const Hills: React.FC<{p?: number; colors?: string[]; y?: number}> = ({p = 0, colors = ['#8fd18a', '#5fb36b', '#3f9657'], y = 700}) => (
  <g stroke={OUT} strokeWidth={6}>
    <path d={`M-300 ${y} Q300 ${y - 200} 800 ${y - 40} T1700 ${y - 90} T2300 ${y - 20} L2300 1300 L-300 1300Z`} fill={colors[0]} transform={`translate(${-p * 30} 0)`} />
    <path d={`M-300 ${y + 90} Q200 ${y - 60} 900 ${y + 60} T2300 ${y + 30} L2300 1300 L-300 1300Z`} fill={colors[1]} transform={`translate(${-p * 60} 0)`} />
    <path d={`M-300 ${y + 200} Q500 ${y + 120} 1200 ${y + 210} T2300 ${y + 180} L2300 1300 L-300 1300Z`} fill={colors[2]} />
  </g>
);

const Floor: React.FC<{y?: number; color?: string; line?: string}> = ({y = 900, color = '#c9a37a', line = '#a8805a'}) => (
  <g>
    <rect x={-300} y={y} width={W + 600} height={H - y + 400} fill={color} stroke={OUT} strokeWidth={6} />
    {Array.from({length: 14}).map((_, i) => (
      <line key={i} x1={-300 + i * 200} y1={y} x2={-420 + i * 230} y2={H + 400} stroke={line} strokeWidth={4} opacity={0.7} />
    ))}
  </g>
);

/* ---------------- Outdoor ---------------- */
export const BgHills: React.FC<BgProps> = ({p = 0, tone = 0}) => (
  <g>
    <Sky p={p} tone={tone} />
    <Hills p={p} colors={night(tone) ? ['#2e4a6b', '#243d5a', '#1b2f48'] : undefined} />
  </g>
);

const Palm: React.FC<{x: number; y: number; s?: number; sway?: number}> = ({x, y, s = 1, sway = 0}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d={`M0 0 Q${20 + sway} -120 ${10 + sway} -260`} stroke={OUT} strokeWidth={30} fill="none" strokeLinecap="round" />
    <path d={`M0 0 Q${20 + sway} -120 ${10 + sway} -260`} stroke="#b88a54" strokeWidth={20} fill="none" strokeLinecap="round" />
    {[-70, -35, 0, 35, 70].map((a, i) => (
      <path key={i} d={`M${10 + sway} -260 q${a * 2.4} ${-60 + Math.abs(a)} ${a * 3} ${40 + Math.abs(a) * 0.6}`} stroke={OUT} strokeWidth={9} fill="none" strokeLinecap="round" />
    ))}
    {[-70, -35, 0, 35, 70].map((a, i) => (
      <path key={i} d={`M${10 + sway} -260 q${a * 2.4} ${-60 + Math.abs(a)} ${a * 3} ${40 + Math.abs(a) * 0.6}`} stroke="#3fae5a" strokeWidth={5} fill="none" strokeLinecap="round" />
    ))}
  </g>
);

export const BgTropic: React.FC<BgProps> = ({p = 0, tone = 3}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <Sky p={p} tone={tone} />
      <Hills p={p} colors={['#6fcf97', '#4fb37b', '#e6c88f']} y={640} />
      <g transform={`translate(${-p * 40} 0)`}>
        {/* simple tiled-roof house */}
        <rect x={1050} y={560} width={420} height={280} fill="#fff1d6" stroke={OUT} strokeWidth={6} />
        <path d="M1010 570 L1260 410 L1510 570Z" fill="#c0563a" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
        <rect x={1220} y={680} width={90} height={160} fill="#8a5a33" stroke={OUT} strokeWidth={5} />
        <rect x={1100} y={620} width={80} height={70} fill="#9fd8ff" stroke={OUT} strokeWidth={5} />
        <rect x={1350} y={620} width={80} height={70} fill="#9fd8ff" stroke={OUT} strokeWidth={5} />
      </g>
      <Palm x={250} y={900} s={1.2} sway={Math.sin(f * 0.05) * 8} />
      <Palm x={1700} y={910} s={1} sway={Math.sin(f * 0.05 + 2) * 8} />
      <Floor y={880} color="#f1d9a6" line="#e0c08a" />
    </g>
  );
};

export const BgKentucky: React.FC<BgProps> = ({p = 0, tone = 0}) => (
  <g>
    <Sky p={p} tone={tone} />
    <Hills p={p} colors={['#9ed67a', '#7cbf5f', '#5da34d']} y={620} />
    <g transform={`translate(${-p * 50} 0)`}>
      {/* brick school building */}
      <rect x={1000} y={380} width={760} height={460} fill="#b5513f" stroke={OUT} strokeWidth={6} />
      <rect x={960} y={340} width={840} height={60} fill="#e8dcc8" stroke={OUT} strokeWidth={6} />
      <path d="M1250 340 L1380 230 L1510 340Z" fill="#e8dcc8" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
      {[0, 1, 2, 3].map((i) =>
        [0, 1].map((j) => (
          <rect key={`${i}${j}`} x={1050 + i * 170} y={430 + j * 150} width={80} height={100} fill={night(tone) ? '#ffe07a' : '#cfe8ff'} stroke={OUT} strokeWidth={5} />
        )),
      )}
      <rect x={1340} y={700} width={100} height={140} fill="#6a4128" stroke={OUT} strokeWidth={5} />
    </g>
    {/* fence */}
    <g stroke={OUT} strokeWidth={5} fill="#f4e9d2">
      {Array.from({length: 14}).map((_, i) => (
        <rect key={i} x={-100 + i * 160} y={800} width={26} height={110} />
      ))}
      <rect x={-300} y={820} width={2600} height={18} />
      <rect x={-300} y={870} width={2600} height={18} />
    </g>
    <Floor y={905} color="#8dc572" line="#79b05e" />
  </g>
);

export const BgCity: React.FC<BgProps> = ({p = 0, tone = 0}) => {
  const f = useCurrentFrame();
  const dark = night(tone);
  return (
    <g>
      <Sky p={p} tone={tone} />
      {[0, 1].map((layer) => (
        <g key={layer} transform={`translate(${-p * (30 + layer * 50)} 0)`} opacity={layer === 0 ? 0.75 : 1}>
          {Array.from({length: 16}).map((_, i) => {
            const bw = 130 + rand(i + layer * 20) * 90;
            const bh = 260 + rand(i + 5 + layer * 9) * 320;
            const bx = -200 + i * 150 + layer * 60;
            const by = 900 - bh + layer * 40;
            return (
              <g key={i}>
                <rect x={bx} y={by} width={bw} height={bh} fill={dark ? (layer ? '#1c2150' : '#2a3070') : layer ? '#7b86b8' : '#a9b3dd'} stroke={OUT} strokeWidth={5} />
                {Array.from({length: Math.floor(bh / 60)}).map((__, r) =>
                  [0, 1].map((c) => {
                    const on = rand(i * 31 + r * 7 + c + layer) > 0.45;
                    return (
                      <rect key={`${r}${c}`} x={bx + 22 + c * (bw / 2 - 8)} y={by + 20 + r * 56} width={bw / 2 - 30} height={30} rx={4} fill={dark && on ? (Math.sin(f * 0.05 + i + r) > -0.9 ? '#ffe07a' : '#6d76b8') : '#e7f0ff'} opacity={dark ? 1 : 0.8} />
                    );
                  }),
                )}
              </g>
            );
          })}
        </g>
      ))}
      <Floor y={900} color={dark ? '#2a2f4a' : '#7d8199'} line={dark ? '#3a4060' : '#9096ad'} />
    </g>
  );
};

/* ---------------- Interiors ---------------- */
const Window: React.FC<{x: number; y: number; w?: number; h?: number; tone?: number; p?: number}> = ({x, y, w = 360, h = 300, tone = 0, p = 0}) => {
  const [a, b] = SKY[tn(tone)];
  return (
    <g>
      <Defs id={`win${x}${tone}`} a={a} b={b} />
      <rect x={x} y={y} width={w} height={h} fill={`url(#win${x}${tone})`} stroke={OUT} strokeWidth={8} />
      <circle cx={x + w * (0.7 - p * 0.1)} cy={y + h * 0.3} r={26} fill={night(tone) ? '#fdf6d8' : '#fff3a0'} />
      <path d={`M${x + w / 2} ${y} V${y + h} M${x} ${y + h / 2} H${x + w}`} stroke={OUT} strokeWidth={8} />
      <rect x={x - 14} y={y + h} width={w + 28} height={16} fill="#e8dcc8" stroke={OUT} strokeWidth={5} />
    </g>
  );
};

export const BgRoom: React.FC<BgProps & {wall?: string; floorColor?: string}> = ({p = 0, tone = 0, wall = '#ffe3c2', floorColor = '#b9804e'}) => (
  <g>
    <rect x={-300} y={-200} width={W + 600} height={1100} fill={night(tone) ? '#2b2f5a' : wall} />
    <rect x={-300} y={820} width={W + 600} height={34} fill={night(tone) ? '#1e2144' : '#fff'} stroke={OUT} strokeWidth={5} opacity={0.9} />
    <Window x={1250} y={170} tone={tone} p={p} />
    <Floor y={850} color={night(tone) ? '#3a3350' : floorColor} line={night(tone) ? '#2a2540' : '#97653a'} />
    {/* shelf */}
    <g transform={`translate(${-p * 20} 0)`}>
      <rect x={140} y={250} width={420} height={18} fill="#8a5a33" stroke={OUT} strokeWidth={5} />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={160 + i * 40} y={170 + (i % 2) * 16} width={30} height={80 - (i % 2) * 16} fill={[C.red, C.blue, C.green, C.orange, C.purple][i]} stroke={OUT} strokeWidth={4} />
      ))}
      <rect x={380} y={190} width={90} height={60} rx={8} fill="#fff" stroke={OUT} strokeWidth={5} />
    </g>
  </g>
);

export const BgClassroom: React.FC<BgProps> = ({p = 0, tone = 0}) => (
  <g>
    <rect x={-300} y={-200} width={W + 600} height={1100} fill="#dfe9d2" />
    <g transform={`translate(${-p * 30} 0)`}>
      <rect x={380} y={170} width={1160} height={460} fill="#2f5d4a" stroke="#8a5a33" strokeWidth={18} />
      <path d="M470 280 Q620 240 760 290 T1060 280" stroke="#e8f5ee" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.85} />
      <path d="M470 390 L900 390 M470 450 L760 450 M1100 360 l120 0 m-60 -60 v120" stroke="#e8f5ee" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.85} />
      <rect x={380} y={640} width={1160} height={18} fill="#8a5a33" stroke={OUT} strokeWidth={5} />
    </g>
    <Window x={40} y={200} w={250} h={260} tone={tone} p={p} />
    <Floor y={880} color="#c9a37a" line="#a8805a" />
  </g>
);

export const BgDiner: React.FC<BgProps> = ({p = 0, tone = 2}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <rect x={-300} y={-200} width={W + 600} height={1100} fill="#2f8f8a" />
      <rect x={-300} y={560} width={W + 600} height={24} fill="#f4e9d2" stroke={OUT} strokeWidth={5} />
      <Window x={120} y={190} w={560} h={300} tone={tone} p={p} />
      <Window x={1240} y={190} w={560} h={300} tone={tone} p={p} />
      {[500, 960, 1420].map((x, i) => (
        <g key={x}>
          <path d={`M${x} -20 V150`} stroke={OUT} strokeWidth={5} />
          <path d={`M${x - 60} 150 Q${x} 90 ${x + 60} 150Z`} fill={C.yellow} stroke={OUT} strokeWidth={5} />
          <ellipse cx={x} cy={160} rx={Math.round(70 + Math.sin(f * 0.1 + i) * 3)} ry={14} fill="#fff7b0" opacity={0.7} />
        </g>
      ))}
      {/* checker floor */}
      <rect x={-300} y={840} width={W + 600} height={400} fill="#f4e9d2" stroke={OUT} strokeWidth={6} />
      {Array.from({length: 30}).map((_, i) =>
        Array.from({length: 4}).map((__, j) =>
          (i + j) % 2 === 0 ? <rect key={`${i}${j}`} x={-300 + i * 90} y={840 + j * 70} width={90} height={70} fill="#d9534f" opacity={0.85} /> : null,
        ),
      )}
    </g>
  );
};

export const BgOffice: React.FC<BgProps> = ({p = 0, tone = 0}) => (
  <g>
    <rect x={-300} y={-200} width={W + 600} height={1100} fill={night(tone) ? '#262a52' : '#e9eefc'} />
    <Window x={80} y={140} w={520} h={380} tone={tone} p={p} />
    <Window x={1300} y={140} w={520} h={380} tone={tone} p={p} />
    <g transform={`translate(${-p * 25} 0)`}>
      <rect x={700} y={200} width={500} height={260} fill="#fff" stroke={OUT} strokeWidth={7} />
      <path d="M740 380 L860 300 L950 350 L1060 250 L1160 330" stroke={C.green} strokeWidth={8} fill="none" strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={790} cy={260} r={16} fill={C.red} />
    </g>
    <Floor y={870} color={night(tone) ? '#34385f' : '#9aa6cf'} line={night(tone) ? '#44497a' : '#8693be'} />
  </g>
);

export const BgCampus: React.FC<BgProps> = ({p = 0, tone = 0}) => (
  <g>
    <Sky p={p} tone={tone} />
    <Hills p={p} y={640} />
    <g transform={`translate(${-p * 40} 0)`}>
      <rect x={520} y={380} width={880} height={400} fill="#f1e2c6" stroke={OUT} strokeWidth={6} />
      <path d="M470 390 L960 240 L1450 390Z" fill="#c9a37a" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={560 + i * 160} y={420} width={50} height={330} fill="#fff7e6" stroke={OUT} strokeWidth={5} />
      ))}
      <rect x={880} y={560} width={160} height={220} fill="#6a4128" stroke={OUT} strokeWidth={5} />
      <circle cx={960} cy={330} r={30} fill="#fff" stroke={OUT} strokeWidth={5} />
    </g>
    <Floor y={900} color="#8dc572" line="#79b05e" />
  </g>
);

export const BgStage: React.FC<BgProps> = ({p = 0}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <Wash id="stg" a="#0b0e24" b="#262b66" />
      {[300, 960, 1620].map((x, i) => (
        <path key={x} d={`M${x} -40 L${x - 260} 900 L${x + 260} 900Z`} fill="#fff6c8" opacity={0.1 + 0.05 * Math.sin(f * 0.07 + i)} />
      ))}
      <g transform={`translate(${-p * 20} 0)`}>
        <rect x={420} y={130} width={1080} height={520} rx={14} fill="#0c1230" stroke={C.green} strokeWidth={8} />
        <rect x={440} y={150} width={1040} height={480} rx={8} fill="#0f1a3c" />
        {Array.from({length: 18}).map((_, i) => (
          <circle key={i} cx={470 + rand(i) * 980} cy={170 + rand(i + 2) * 440} r={3 + rand(i + 4) * 4} fill={C.green} opacity={0.35 + 0.35 * Math.sin(f * 0.08 + i)} />
        ))}
      </g>
      <rect x={-300} y={860} width={W + 600} height={400} fill="#1a1d40" stroke={C.green} strokeWidth={6} />
      <rect x={-300} y={860} width={W + 600} height={10} fill={C.green} opacity={0.9} />
    </g>
  );
};

const Rack: React.FC<{x: number; y: number; w: number; h: number; seed: number}> = ({x, y, w, h, seed}) => {
  const f = useCurrentFrame();
  const rows = Math.floor(h / 46);
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} fill="#232a4a" stroke={OUT} strokeWidth={5} />
      {Array.from({length: rows}).map((_, r) => (
        <g key={r}>
          <rect x={x + 10} y={y + 10 + r * 46} width={w - 20} height={34} rx={4} fill="#2f3866" stroke={OUT} strokeWidth={3} />
          {[0, 1, 2].map((c) => (
            <circle key={c} cx={x + 28 + c * 22} cy={y + 27 + r * 46} r={5} fill={Math.sin(f * 0.2 + seed + r * 1.7 + c * 2.3) > 0 ? C.green : '#456'} />
          ))}
        </g>
      ))}
    </g>
  );
};

export const BgDatacenter: React.FC<BgProps> = ({p = 0}) => (
  <g>
    <Wash id="dc" a="#0e1630" b="#1e2d5c" />
    <g transform={`translate(${-p * 40} 0)`}>
      {Array.from({length: 8}).map((_, i) => (
        <Rack key={`a${i}`} x={-100 + i * 270} y={260} w={220} h={560} seed={i} />
      ))}
    </g>
    <rect x={-300} y={820} width={W + 600} height={400} fill="#1b2140" stroke={OUT} strokeWidth={6} />
    {Array.from({length: 9}).map((_, i) => (
      <line key={i} x1={-300 + i * 300} y1={820} x2={-500 + i * 340} y2={1300} stroke="#2e3a70" strokeWidth={4} />
    ))}
    <rect x={-300} y={820} width={W + 600} height={8} fill={C.green} opacity={0.8} />
  </g>
);

export const BgBlueprint: React.FC<BgProps> = ({p = 0}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <rect x={-300} y={-200} width={W + 600} height={H + 400} fill="#10265a" />
      {Array.from({length: 34}).map((_, i) => (
        <line key={`v${i}`} x1={-300 + i * 80 - p * 30} y1={-200} x2={-300 + i * 80 - p * 30} y2={1300} stroke="#2c4a95" strokeWidth={2} />
      ))}
      {Array.from({length: 18}).map((_, i) => (
        <line key={`h${i}`} x1={-300} y1={-200 + i * 80} x2={2300} y2={-200 + i * 80} stroke="#2c4a95" strokeWidth={2} />
      ))}
      {Array.from({length: 7}).map((_, i) => (
        <path key={i} d={`M${-200 + i * 330} ${150 + rand(i) * 700} h160 v${60 + rand(i + 3) * 120} h120`} stroke="#5fa8ff" strokeWidth={4} fill="none" strokeDasharray="14 10" strokeDashoffset={-f * 1.5} />
      ))}
    </g>
  );
};

export const BgGlow: React.FC<BgProps & {color?: string}> = ({p = 0, color = C.green}) => {
  const f = useCurrentFrame();
  return (
    <g>
      <defs>
        <radialGradient id={`glow${color}`} cx="50%" cy="50%" r="60%">
          <stop offset="0" stopColor={color} stopOpacity={0.55} />
          <stop offset="1" stopColor="#0b0e24" stopOpacity={1} />
        </radialGradient>
      </defs>
      <rect x={-300} y={-200} width={W + 600} height={H + 400} fill="#0b0e24" />
      <rect x={-300} y={-200} width={W + 600} height={H + 400} fill={`url(#glow${color})`} />
      {Array.from({length: 40}).map((_, i) => (
        <circle key={i} cx={rand(i) * 2200 - 150 - p * 30} cy={((rand(i + 9) * 1400 - f * (0.4 + rand(i) * 0.6) + 1400) % 1400) - 150} r={2 + rand(i + 3) * 4} fill={color} opacity={0.5} />
      ))}
    </g>
  );
};

export const BgSunrise: React.FC<BgProps> = ({p = 0}) => (
  <g>
    <Sky p={p} tone={1} />
    <circle cx={960} cy={720 - p * 60} r={160} fill="#ffcf6b" opacity={0.9} />
    <Hills p={p} colors={['#5b4a8a', '#443a7a', '#2f2a63']} y={720} />
  </g>
);
export const BgSky: React.FC<BgProps> = (props) => <Sky {...props} />;
