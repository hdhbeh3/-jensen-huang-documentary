import React from 'react';
import {useCurrentFrame} from 'remotion';
import {OUT} from '../theme';
import {clamp01, easeInOut, lerp} from '../lib/anim';
import {useShot, useSpeech} from './context';
import {Look, LOOKS, LookName} from './looks';

/* ------------------------------------------------------------------ */
/* Expressions                                                          */
/* ------------------------------------------------------------------ */
export type Expression =
  | 'neutral' | 'happy' | 'laugh' | 'sad' | 'worried' | 'surprised' | 'determined' | 'thinking';

/* ------------------------------------------------------------------ */
/* Poses: [shoulder angle, elbow bend] per arm, [hip, knee] per leg.     */
/* Angles in degrees from "straight down", positive = toward screen     */
/* right. Elbow/knee angles are relative to the upper segment.          */
/* ------------------------------------------------------------------ */
type J = [number, number];
export interface PoseDef {
  la: J; ra: J; ll: J; rl: J;
  lean?: number; // head tilt in degrees
  drop?: number; // body drop (sitting etc.)
}
export const POSES = {
  idle: {la: [-10, -8], ra: [10, 8], ll: [-4, 0], rl: [4, 0]},
  point: {la: [-10, -8], ra: [88, -4], ll: [-4, 0], rl: [4, 0]},
  pointUp: {la: [-10, -8], ra: [158, 0], ll: [-4, 0], rl: [4, 0]},
  armsUp: {la: [-158, -8], ra: [158, 8], ll: [-8, 0], rl: [8, 0]},
  armsOpen: {la: [-72, -14], ra: [72, 14], ll: [-6, 0], rl: [6, 0]},
  think: {la: [-10, -8], ra: [80, 164], ll: [-4, 0], rl: [4, 0], lean: -6},
  shrug: {la: [-38, -105], ra: [38, 105], ll: [-4, 0], rl: [4, 0], lean: 5},
  hold: {la: [-15, 135], ra: [15, -135], ll: [-4, 0], rl: [4, 0]},
  hips: {la: [-40, 100], ra: [40, -100], ll: [-6, 0], rl: [6, 0]},
  slump: {la: [-4, -3], ra: [4, 3], ll: [-3, 0], rl: [3, 0], lean: 14},
  reach: {la: [-10, -8], ra: [104, 0], ll: [-4, 0], rl: [4, 0]},
  both: {la: [-95, 8], ra: [95, -8], ll: [-4, 0], rl: [4, 0]},
  carry: {la: [-20, 120], ra: [20, -120], ll: [-4, 0], rl: [4, 0]},
  sit: {la: [-25, 70], ra: [25, -70], ll: [80, -80], rl: [86, -86], drop: 52},
  sitReach: {la: [-25, 70], ra: [70, -20], ll: [80, -80], rl: [86, -86], drop: 52},
  write: {la: [-14, 60], ra: [42, 76], ll: [-4, 0], rl: [4, 0], lean: 8},
  cross: {la: [-5, 128], ra: [5, -128], ll: [-4, 0], rl: [4, 0]},
} satisfies Record<string, PoseDef>;
export type PoseName = keyof typeof POSES;

export type Motion = 'none' | 'walk' | 'wave' | 'talk' | 'type' | 'cheer' | 'nod' | 'work' | 'pace';

/* ------------------------------------------------------------------ */
const rad = (d: number) => (d * Math.PI) / 180;
const A1 = 42, A2 = 40, T1 = 52, T2 = 52;
const SHOULDER_Y = -78, SHOULDER_X = 16, HIP_X = 9;
const NECK_Y = -86;
const mixJ = (a: J, b: J, t: number): J => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];

function chain(ox: number, oy: number, a1: number, a2: number, l1: number, l2: number) {
  const ex = ox + Math.sin(rad(a1)) * l1;
  const ey = oy + Math.cos(rad(a1)) * l1;
  const hx = ex + Math.sin(rad(a1 + a2)) * l2;
  const hy = ey + Math.cos(rad(a1 + a2)) * l2;
  return [[ox, oy], [ex, ey], [hx, hy]];
}

const Limb: React.FC<{pts: number[][]; w: number; color: string}> = ({pts, w, color}) => {
  const d = 'M' + pts.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' L');
  return (
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d={d} stroke={OUT} strokeWidth={w + 8} />
      <path d={d} stroke={color} strokeWidth={w} />
    </g>
  );
};

/* ------------------------------------------------------------------ */
/* Hair                                                                 */
/* ------------------------------------------------------------------ */
const Hair: React.FC<{look: Look; front: boolean}> = ({look, front}) => {
  const {hair, hairStyle, silver} = look;
  const st = {stroke: OUT, strokeWidth: 4, strokeLinejoin: 'round' as const};
  if (!front) {
    if (hairStyle === 'long')
      return <path d="M-34 -4 C-40 40 -30 52 -18 50 L18 50 C30 52 40 40 34 -4 C34 -40 -34 -40 -34 -4Z" fill={hair} {...st} />;
    if (hairStyle === 'bun') return <circle cx={0} cy={-40} r={13} fill={hair} {...st} />;
    return null;
  }
  switch (hairStyle) {
    case 'side': // Jensen: thick side-swept hair
      return (
        <g>
          <path d="M-33 -2 C-38 -36 -8 -50 20 -41 C37 -35 37 -14 33 -2 C27 -19 10 -27 -6 -24 C-20 -22 -28 -14 -33 -2Z" fill={hair} {...st} />
          {silver && <path d="M-4 -40 C6 -42 16 -38 22 -32" stroke="#a7a9b8" strokeWidth={3} fill="none" strokeLinecap="round" />}
        </g>
      );
    case 'short':
      return <path d="M-32 -4 C-36 -38 -6 -46 18 -41 C36 -36 36 -14 32 -4 C20 -20 -14 -22 -32 -4Z" fill={hair} {...st} />;
    case 'curly':
      return (
        <g fill={hair} {...st}>
          {[-24, -12, 0, 12, 24].map((x, i) => (
            <circle key={i} cx={x} cy={-27 - (i % 2 === 0 ? 4 : 10)} r={12} />
          ))}
        </g>
      );
    case 'cap':
      return (
        <g>
          <path d="M-33 -8 C-34 -44 34 -44 33 -8Z" fill={look.top} {...st} />
          <path d="M20 -12 L52 -6 L50 0 L18 -2Z" fill={look.top} {...st} />
        </g>
      );
    case 'bun':
      return <path d="M-32 -4 C-36 -38 -6 -46 18 -41 C36 -36 36 -14 32 -4 C14 -24 -16 -24 -32 -4Z" fill={hair} {...st} />;
    case 'long':
      return <path d="M-34 -2 C-40 -40 40 -40 34 -2 C24 -24 -22 -24 -34 -2Z" fill={hair} {...st} />;
    case 'bald':
      return (
        <g fill={hair} {...st}>
          <path d="M-33 -2 C-35 -14 -33 -20 -29 -24 L-30 -4Z" />
          <path d="M33 -2 C35 -14 33 -20 29 -24 L30 -4Z" />
        </g>
      );
  }
  return null;
};

/* ------------------------------------------------------------------ */
/* Face                                                                 */
/* ------------------------------------------------------------------ */
const BROWS: Record<Expression, {l: [number, number]; r: [number, number]}> = {
  neutral: {l: [0, 0], r: [0, 0]},
  happy: {l: [-1, -4], r: [-1, -4]},
  laugh: {l: [-2, -6], r: [-2, -6]},
  sad: {l: [-6, 1], r: [-6, 1]},
  worried: {l: [-8, 0], r: [-8, 0]},
  surprised: {l: [-9, -9], r: [-9, -9]},
  determined: {l: [4, -2], r: [4, -2]},
  thinking: {l: [0, 0], r: [-7, -7]},
};

const Face: React.FC<{expr: Expression; look: Look; open: number; blink: boolean; dir: [number, number]}> = ({
  expr, look, open, blink, dir,
}) => {
  const ink = OUT;
  const eyeR = expr === 'surprised' ? 4.8 : 3.8;
  const brow = BROWS[expr];
  const happyEyes = expr === 'happy' || expr === 'laugh';
  const speaking = open > 0.06 && expr !== 'laugh';
  const mouth = (() => {
    if (speaking)
      return <ellipse cx={0} cy={15} rx={6 + open * 2} ry={2 + open * 7} fill="#6b1d2a" stroke={ink} strokeWidth={3} />;
    switch (expr) {
      case 'happy': return <path d="M-10 11 Q0 24 10 11" fill="none" stroke={ink} strokeWidth={3.5} strokeLinecap="round" />;
      case 'laugh': return <path d="M-11 10 Q0 12 11 10 Q8 27 0 27 Q-8 27 -11 10Z" fill="#6b1d2a" stroke={ink} strokeWidth={3} strokeLinejoin="round" />;
      case 'sad': return <path d="M-8 20 Q0 11 8 20" fill="none" stroke={ink} strokeWidth={3.5} strokeLinecap="round" />;
      case 'worried': return <path d="M-8 17 Q-4 13 0 17 Q4 21 8 17" fill="none" stroke={ink} strokeWidth={3.2} strokeLinecap="round" />;
      case 'surprised': return <ellipse cx={0} cy={17} rx={5} ry={7} fill="#6b1d2a" stroke={ink} strokeWidth={3} />;
      case 'determined': return <path d="M-8 15 L8 13" stroke={ink} strokeWidth={4} strokeLinecap="round" />;
      case 'thinking': return <path d="M-6 16 L6 12" stroke={ink} strokeWidth={3.5} strokeLinecap="round" />;
      default: return <path d="M-7 14 L7 14" stroke={ink} strokeWidth={3.5} strokeLinecap="round" />;
    }
  })();
  return (
    <g>
      {(expr === 'happy' || expr === 'laugh') && (
        <g fill="#ff8aa0" opacity={0.5}>
          <circle cx={-20} cy={10} r={5} />
          <circle cx={20} cy={10} r={5} />
        </g>
      )}
      {[-1, 1].map((s) => {
        const b = s === -1 ? brow.l : brow.r;
        const ex = s * 12 + dir[0] * 2.5;
        const ey = -3 + dir[1] * 2.5;
        return (
          <g key={s}>
            <path d={`M${s * 6} ${-15 + b[0]} L${s * 19} ${-15 + b[1]}`} stroke={look.hair === '#d9d9e3' ? '#aaa' : OUT} strokeWidth={4} strokeLinecap="round" />
            {happyEyes ? (
              <path d={`M${s * 12 - 5} -1 Q${s * 12} -9 ${s * 12 + 5} -1`} fill="none" stroke={ink} strokeWidth={3.4} strokeLinecap="round" />
            ) : blink ? (
              <path d={`M${s * 12 - 4.5} -3 L${s * 12 + 4.5} -3`} stroke={ink} strokeWidth={3} strokeLinecap="round" />
            ) : (
              <g>
                <circle cx={ex} cy={ey} r={eyeR} fill={ink} />
                <circle cx={ex + 1.3} cy={ey - 1.4} r={1.3} fill="#fff" />
              </g>
            )}
          </g>
        );
      })}
      {look.glasses && (
        <g fill="#cfe8ff" fillOpacity={0.28} stroke={ink} strokeWidth={3.4}>
          <rect x={-22} y={-12} width={20} height={17} rx={6} />
          <rect x={2} y={-12} width={20} height={17} rx={6} />
          <path d="M-2 -5 L2 -5" fill="none" />
          <path d="M-22 -6 L-31 -9 M22 -6 L31 -9" fill="none" />
        </g>
      )}
      {look.mustache && <path d="M-11 10 Q-5 5 0 9 Q5 5 11 10 Q5 12 0 10 Q-5 12 -11 10Z" fill={look.hair} stroke={ink} strokeWidth={2} />}
      {mouth}
    </g>
  );
};

/* ------------------------------------------------------------------ */
/* Stickman                                                             */
/* ------------------------------------------------------------------ */
export interface StickmanProps {
  look?: LookName | Look;
  x: number;
  y?: number; // y of the feet (ground). Default 900.
  scale?: number;
  flip?: boolean;
  expr?: Expression;
  pose?: PoseName | [PoseName, PoseName]; // a pair is blended across the shot
  motion?: Motion;
  speaking?: boolean; // mouth follows the narration loudness
  lookDir?: [number, number];
  seed?: number; // desyncs idle/blink between several characters
  speed?: number; // motion speed multiplier
}

export const Stickman: React.FC<StickmanProps> = ({
  look = 'jensenCEO', x, y = 900, scale = 1, flip = false, expr = 'neutral', pose = 'idle',
  motion = 'none', speaking = false, lookDir = [0, 0], seed = 0, speed = 1,
}) => {
  const f = useCurrentFrame();
  const {dur} = useShot();
  const speech = useSpeech();
  const L: Look = typeof look === 'string' ? LOOKS[look] : look;
  const t = f * speed + seed * 17;

  // --- resolve pose (optionally blended across the shot) ---
  let P: PoseDef;
  if (Array.isArray(pose)) {
    const k = easeInOut(clamp01(f / Math.max(1, dur - 1)));
    const a = POSES[pose[0]] as PoseDef, b = POSES[pose[1]] as PoseDef;
    P = {
      la: mixJ(a.la, b.la, k), ra: mixJ(a.ra, b.ra, k), ll: mixJ(a.ll, b.ll, k), rl: mixJ(a.rl, b.rl, k),
      lean: lerp(a.lean ?? 0, b.lean ?? 0, k),
    };
  } else {
    P = POSES[pose] as PoseDef;
  }
  let la = [...P.la] as J, ra = [...P.ra] as J, ll = [...P.ll] as J, rl = [...P.rl] as J;
  let lean = P.lean ?? 0;
  let bob = Math.sin(t * 0.09) * 1.2; // breathing
  let lift = 0;

  // --- procedural motion layered on the pose ---
  switch (motion) {
    case 'walk': {
      const ph = t * 0.3;
      ll = [Math.sin(ph) * 30, Math.max(0, Math.sin(ph + 1.4)) * 32];
      rl = [-Math.sin(ph) * 30, Math.max(0, -Math.sin(ph + 1.4)) * 32];
      la = [-8 - Math.sin(ph) * 24, -10];
      ra = [8 - Math.sin(ph) * -24, 10];
      bob = Math.abs(Math.sin(ph)) * 4;
      break;
    }
    case 'pace': {
      const ph = t * 0.2;
      ll = [Math.sin(ph) * 14, Math.max(0, Math.sin(ph + 1.4)) * 12];
      rl = [-Math.sin(ph) * 14, Math.max(0, -Math.sin(ph + 1.4)) * 12];
      bob = Math.abs(Math.sin(ph)) * 2;
      break;
    }
    case 'wave':
      ra = [150, -18 + Math.sin(t * 0.5) * 34];
      break;
    case 'talk':
      la = [la[0] + Math.sin(t * 0.16) * 12, la[1] + Math.sin(t * 0.22) * 22];
      ra = [ra[0] + Math.sin(t * 0.13 + 1) * 14, ra[1] + Math.sin(t * 0.2 + 2) * 22];
      lean += Math.sin(t * 0.11) * 3;
      break;
    case 'type':
      la = [-8, 78 + Math.sin(t * 0.9) * 10];
      ra = [8, -78 + Math.sin(t * 0.9 + 2) * 10];
      lean = 8;
      break;
    case 'work':
      ra = [50 + Math.sin(t * 0.45) * 10, 70 + Math.sin(t * 0.8) * 20];
      la = [-14, 60];
      lean = 8;
      break;
    case 'cheer': {
      const s = Math.sin(t * 0.32);
      la = [-150 - s * 12, -8];
      ra = [150 + s * 12, 8];
      lift = Math.abs(s) * 22;
      break;
    }
    case 'nod':
      lean += Math.sin(t * 0.25) * 6;
      break;
    default:
  }

  const blink = (f + seed * 37) % 110 < 4;
  const open = speaking ? Math.min(1, speech * 1.15) : 0;
  const drop = P.drop ?? 0;
  const hipY = 0;

  // --- skeleton ---
  const lArm = chain(-SHOULDER_X, SHOULDER_Y, la[0], la[1], A1, A2);
  const rArm = chain(SHOULDER_X, SHOULDER_Y, ra[0], ra[1], A1, A2);
  const lLeg = chain(-HIP_X, hipY, ll[0], ll[1], T1, T2);
  const rLeg = chain(HIP_X, hipY, rl[0], rl[1], T1, T2);

  const jacket = L.jacket;
  const sleeve = jacket && jacket !== 'apron' ? L.jacketColor : L.top;
  const torsoColor = jacket === 'apron' || !jacket ? L.top : L.jacketColor;
  const head = L.headScale;

  const body = (
    <g transform={`translate(0 ${-104 - lift + drop})`}>
      <g transform={`translate(0 ${-bob * 0.6})`}>
        {/* legs */}
        <Limb pts={lLeg} w={16} color={L.bottom} />
        <Limb pts={rLeg} w={16} color={L.bottom} />
        {[lLeg, rLeg].map((leg, i) => (
          <ellipse key={i} cx={leg[2][0] + 6} cy={leg[2][1] + 3} rx={12} ry={6.5} fill={L.shoe ?? '#2b2740'} stroke={OUT} strokeWidth={4} />
        ))}

        {/* torso */}
        <path d="M-23 -82 Q0 -92 23 -82 L20 3 Q0 9 -20 3 Z" fill={torsoColor} stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
        {jacket === 'leather' && (
          <g>
            <path d="M-9 -88 L0 -58 L-14 -64 Z M9 -88 L0 -58 L14 -64 Z" fill="#2b2b35" stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
            <path d="M0 -58 L0 2" stroke="#9aa0b4" strokeWidth={2.4} />
            <path d="M-16 -76 Q-12 -60 -15 -40" stroke="#4a4a58" strokeWidth={4} fill="none" strokeLinecap="round" />
            <path d="M-6 -86 L0 -62 L6 -86Z" fill="#2c2c34" />
          </g>
        )}
        {jacket === 'blazer' && (
          <g>
            <path d="M-9 -88 L0 -40 L9 -88 Z" fill={L.top} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
            <path d="M-9 -88 L-2 -50 L-16 -70 Z M9 -88 L2 -50 L16 -70 Z" fill={L.jacketColor} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />
          </g>
        )}
        {jacket === 'hoodie' && (
          <g>
            <path d="M-14 -86 Q0 -70 14 -86" fill={L.jacketColor} stroke={OUT} strokeWidth={4} />
            <path d="M-4 -74 L-4 -50 M4 -74 L4 -50" stroke="#e8ebf5" strokeWidth={2.4} strokeLinecap="round" />
          </g>
        )}
        {jacket === 'apron' && (
          <path d="M-15 -62 L15 -62 L18 2 L-18 2Z" fill={L.jacketColor} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
        )}

        {/* arms */}
        <Limb pts={lArm} w={15} color={sleeve} />
        <Limb pts={rArm} w={15} color={sleeve} />
        <circle cx={lArm[2][0]} cy={lArm[2][1]} r={8} fill={L.skin} stroke={OUT} strokeWidth={4} />
        <circle cx={rArm[2][0]} cy={rArm[2][1]} r={8} fill={L.skin} stroke={OUT} strokeWidth={4} />

        {/* neck + head */}
        <rect x={-6} y={NECK_Y - 4} width={12} height={12} fill={L.skin} stroke={OUT} strokeWidth={3} />
        <g transform={`translate(0 ${NECK_Y}) rotate(${lean}) translate(0 ${-30 * head + 2}) scale(${head})`}>
          <Hair look={L} front={false} />
          <circle cx={-31} cy={2} r={6} fill={L.skin} stroke={OUT} strokeWidth={3.5} />
          <circle cx={31} cy={2} r={6} fill={L.skin} stroke={OUT} strokeWidth={3.5} />
          <ellipse cx={0} cy={0} rx={31} ry={32} fill={L.skin} stroke={OUT} strokeWidth={6} />
          {L.beard && <path d="M-29 6 Q-27 38 0 38 Q27 38 29 6 Q20 24 0 24 Q-20 24 -29 6Z" fill={L.hair} stroke={OUT} strokeWidth={3} strokeLinejoin="round" />}
          <Hair look={L} front />
          <Face expr={expr} look={L} open={open} blink={blink} dir={lookDir} />
        </g>
      </g>
    </g>
  );

  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -scale * L.height : scale * L.height} ${scale * L.height})`}>
      {/* soft ground shadow */}
      <ellipse cx={0} cy={4} rx={48} ry={9} fill="#000" opacity={0.16} />
      {body}
    </g>
  );
};
