import React from 'react';
import {W, H} from '../theme';
import {easeInOut, lerp} from '../lib/anim';

type Move = 'push' | 'pull' | 'panL' | 'panR' | 'panUp' | 'drift';
const MOVES: Move[] = ['push', 'panR', 'pull', 'panL', 'panUp', 'drift'];

const cam = (m: Move, t: number) => {
  switch (m) {
    case 'push': return {s: lerp(1.0, 1.13, t), x: 0, y: lerp(0, -10, t)};
    case 'pull': return {s: lerp(1.13, 1.0, t), x: 0, y: 0};
    case 'panL': return {s: 1.08, x: lerp(55, -55, t), y: 0};
    case 'panR': return {s: 1.08, x: lerp(-55, 55, t), y: 0};
    case 'panUp': return {s: 1.08, x: 0, y: lerp(35, -35, t)};
    default: return {s: lerp(1.03, 1.07, t), x: Math.sin(t * Math.PI) * 30, y: Math.cos(t * Math.PI) * 14};
  }
};

/** Subtle camera move (pan / zoom) around the centre of the 1920x1080 stage. */
export const Camera: React.FC<{k: number; v: number; p: number; children: React.ReactNode}> = ({k, v, p, children}) => {
  const move = MOVES[(k + v * 2) % MOVES.length];
  const c = cam(move, easeInOut(p));
  return (
    <g transform={`translate(${W / 2} ${H / 2}) scale(${c.s}) translate(${-W / 2 + c.x} ${-H / 2 + c.y})`}>{children}</g>
  );
};
