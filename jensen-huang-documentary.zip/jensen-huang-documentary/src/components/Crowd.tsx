import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, OUT} from '../theme';
import {rand} from '../lib/anim';

/** A row of silhouetted audience members. Some raise their arms and cheer. */
export const Crowd: React.FC<{y?: number; n?: number; color?: string; cheer?: number; phones?: boolean}> = ({y = 1010, n = 12, color = '#0a0d22', cheer = 0.5, phones = false}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const x = -40 + (i + rand(i) * 0.5) * (2000 / n);
        const up = rand(i + 11) < cheer;
        const bob = Math.sin(f * 0.25 + i * 1.3) * (up ? 12 : 3);
        const r = 44 + rand(i + 2) * 12;
        return (
          <g key={i} transform={`translate(${x} ${y + bob})`}>
            {up && (
              <g stroke={color} strokeWidth={22} strokeLinecap="round">
                <line x1={-34} y1={20} x2={-62} y2={-100 - 14 * Math.sin(f * 0.3 + i)} />
                <line x1={34} y1={20} x2={62} y2={-100 - 14 * Math.sin(f * 0.3 + i + 1)} />
              </g>
            )}
            {phones && !up && (
              <g>
                <line x1={30} y1={20} x2={46} y2={-90} stroke={color} strokeWidth={20} strokeLinecap="round" />
                <rect x={34} y={-140} width={32} height={56} rx={6} fill="#cfe8ff" stroke={color} strokeWidth={5} opacity={0.85} />
              </g>
            )}
            <circle cy={-60} r={r * 0.6} fill={color} stroke={C.green} strokeWidth={3} opacity={1} />
            <path d={`M${-r} 80 Q${-r} 0 0 0 Q${r} 0 ${r} 80Z`} fill={color} stroke={C.green} strokeWidth={3} />
          </g>
        );
      })}
      <rect x={-100} y={y + 70} width={2200} height={300} fill={color} stroke="none" />
      <rect x={-100} y={y + 66} width={2200} height={4} fill={OUT} opacity={0} />
    </g>
  );
};
