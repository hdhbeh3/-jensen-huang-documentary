import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, FONT, OUT} from '../theme';
import {easeOut, tween} from '../lib/anim';

/** Soft vignette over the whole film for a cohesive look. */
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 62%, rgba(10,12,30,0.38) 100%)'}} />
);

/** Fade up from black at the start and down to black at the end. */
export const FadeInOut: React.FC<{total: number}> = ({total}) => {
  const f = useCurrentFrame();
  const o = Math.max(tween(f, 0, 14, 1, 0, (t) => t), tween(f, total - 48, total - 1, 0, 1, (t) => t));
  return <AbsoluteFill style={{background: '#000', opacity: o, pointerEvents: 'none'}} />;
};

/** Chapter title card (lower third) + a quick green wipe. Place inside a Sequence that starts at the chapter. */
export const ChapterCard: React.FC<{index: number; title: string; subtitle: string; wipe: boolean}> = ({index, title, subtitle, wipe}) => {
  const f = useCurrentFrame();
  const {width} = useVideoConfig();
  const inK = tween(f, 4, 20, 0, 1, easeOut);
  const outK = tween(f, 76, 92, 0, 1);
  const x = (1 - inK) * -700 - outK * 700;
  const wipeX = tween(f, 0, 16, -width, width, (t) => t * t * (3 - 2 * t));
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {wipe && f < 18 && <div style={{position: 'absolute', top: 0, bottom: 0, left: wipeX, width, background: C.green}} />}
      <div style={{position: 'absolute', left: 90, bottom: 90, transform: `translateX(${x}px)`, fontFamily: FONT}}>
        <div style={{display: 'flex', alignItems: 'stretch', filter: 'drop-shadow(0 8px 0 rgba(0,0,0,0.25))'}}>
          <div style={{width: 18, background: C.green, border: `5px solid ${OUT}`, borderRight: 'none'}} />
          <div style={{background: '#fff', border: `5px solid ${OUT}`, padding: '16px 34px 18px 28px', borderRadius: '0 16px 16px 0'}}>
            <div style={{fontSize: 24, fontWeight: 800, letterSpacing: 4, color: C.greenDark}}>CHAPTER {index + 1}</div>
            <div style={{fontSize: 52, fontWeight: 900, color: OUT, lineHeight: 1.1}}>{title}</div>
            <div style={{fontSize: 26, fontWeight: 600, color: '#4a4f66', marginTop: 2}}>{subtitle}</div>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
