import React, {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';
import timing from '../data/timing.json';

export interface ShotInfo {
  dur: number; // frames in this shot
  from: number; // absolute start frame in the film
  k: number; // index of this shot inside its chapter
  v: number; // variant (0,1,2...) increments each time a shot template repeats
}

export const ShotCtx = createContext<ShotInfo>({dur: 72, from: 0, k: 0, v: 0});
export const useShot = () => useContext(ShotCtx);

/** Local frame, shot progress 0..1 and shot info in one hook. */
export const useP = () => {
  const f = useCurrentFrame();
  const info = useShot();
  return {...info, f, p: info.dur > 1 ? Math.min(1, f / (info.dur - 1)) : 0};
};

/** Narration loudness (0..1) at the current frame — drives mouth movement. */
export const useSpeech = () => {
  const f = useCurrentFrame();
  const {from} = useShot();
  const env = timing.envelope as number[];
  return env[from + f] ?? 0;
};
