import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT, OUT} from '../theme';
import {clamp01, pop, rand, tween, wob} from '../lib/anim';

/** Props are drawn around their local origin (0,0) and placed with x / y / s. */
interface PP {
  x: number;
  y: number;
  s?: number;
  rot?: number;
  delay?: number; // frames before the prop pops in (0 = always visible)
  children?: React.ReactNode;
}

/** Wrapper: position, scale, optional pop-in. */
export const At: React.FC<PP> = ({x, y, s = 1, rot = 0, delay, children}) => {
  const f = useCurrentFrame();
  const k = delay === undefined ? 1 : pop(f, delay, 12);
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s * k})`} opacity={k > 0 ? 1 : 0}>
      {children}
    </g>
  );
};

const st = {stroke: OUT, strokeWidth: 6, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export const Label: React.FC<{x?: number; y?: number; size?: number; color?: string; children: React.ReactNode; weight?: number; anchor?: 'start' | 'middle' | 'end'}> = ({x = 0, y = 0, size = 28, color = '#fff', children, weight = 800, anchor = 'middle'}) => (
  <text x={x} y={y} fontFamily={FONT} fontSize={size} fontWeight={weight} fill={color} textAnchor={anchor}>
    {children}
  </text>
);

/* ---------------- Hardware ---------------- */
export const Chip: React.FC<PP & {label?: string; glow?: boolean}> = ({label = 'GPU', glow = true, ...p}) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      {glow && <circle r={190} fill={C.green} opacity={0.12 + 0.06 * Math.sin(f * 0.15)} />}
      {Array.from({length: 8}).map((_, i) => (
        <g key={i} stroke={OUT} strokeWidth={5} fill="#c9ced9">
          <rect x={-84 + i * 24} y={-128} width={14} height={30} />
          <rect x={-84 + i * 24} y={98} width={14} height={30} />
          <rect x={-128} y={-84 + i * 24} width={30} height={14} />
          <rect x={98} y={-84 + i * 24} width={30} height={14} />
        </g>
      ))}
      <rect x={-100} y={-100} width={200} height={200} rx={20} fill="#2a3158" {...st} />
      <rect x={-74} y={-74} width={148} height={148} rx={10} fill="#10152f" stroke={C.green} strokeWidth={4} />
      {Array.from({length: 4}).map((_, i) =>
        Array.from({length: 4}).map((__, j) => (
          <rect key={`${i}${j}`} x={-58 + i * 30} y={-58 + j * 30} width={22} height={22} rx={3} fill={C.green} opacity={0.35 + 0.55 * Math.abs(Math.sin(f * 0.12 + i * 1.3 + j * 0.7))} />
        )),
      )}
      <Label y={118 + 38} size={26} color={C.green}>{label}</Label>
    </At>
  );
};

export const Card: React.FC<PP & {label?: string; spin?: boolean}> = ({label = 'GPU', spin = true, ...p}) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <rect x={-170} y={-70} width={340} height={140} rx={14} fill="#1e2347" {...st} />
      <rect x={-150} y={70} width={210} height={20} fill="#e5c26a" stroke={OUT} strokeWidth={4} />
      <rect x={-188} y={-92} width={20} height={190} fill="#c9ced9" {...st} />
      <circle cx={-20} cy={0} r={52} fill="#10152f" {...st} />
      <g transform={`translate(-20 0) rotate(${spin ? f * 14 : 0})`}>
        {[0, 72, 144, 216, 288].map((a) => (
          <path key={a} d="M0 0 Q18 -20 0 -44 Q-16 -22 0 0" fill={C.green} stroke={OUT} strokeWidth={3} transform={`rotate(${a})`} />
        ))}
      </g>
      <circle cx={-20} cy={0} r={8} fill="#c9ced9" stroke={OUT} strokeWidth={3} />
      <rect x={60} y={-52} width={84} height={104} rx={8} fill="#2a3158" stroke={C.green} strokeWidth={4} />
      <Label x={102} y={8} size={22} color={C.green}>{label}</Label>
    </At>
  );
};

export const Monitor: React.FC<PP & {w?: number; h?: number; screen?: string}> = ({w = 320, h = 200, screen = '#10152f', children, ...p}) => (
  <At {...p}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={12} fill="#2b2f4a" {...st} />
    <rect x={-w / 2 + 14} y={-h / 2 + 14} width={w - 28} height={h - 28} rx={6} fill={screen} />
    <g transform={`translate(${-w / 2 + 14} ${-h / 2 + 14})`}>{children}</g>
    <path d={`M-30 ${h / 2} L-44 ${h / 2 + 50} H44 L30 ${h / 2}Z`} fill="#3a3f5c" {...st} />
    <rect x={-70} y={h / 2 + 48} width={140} height={16} rx={6} fill="#3a3f5c" {...st} />
  </At>
);

export const Laptop: React.FC<PP & {screen?: string}> = ({screen = '#10152f', children, ...p}) => (
  <At {...p}>
    <rect x={-120} y={-150} width={240} height={150} rx={10} fill="#3a3f5c" {...st} />
    <rect x={-104} y={-136} width={208} height={120} rx={4} fill={screen} />
    <g transform="translate(-104 -136)">{children}</g>
    <path d="M-150 0 H150 L130 24 H-130Z" fill="#c9ced9" {...st} />
  </At>
);

export const Tower: React.FC<PP & {cards?: number; label?: string}> = ({cards = 1, label, ...p}) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <rect x={-90} y={-220} width={180} height={440} rx={14} fill="#2b2f4a" {...st} />
      <rect x={-70} y={-196} width={140} height={300} rx={8} fill="#10152f" stroke={C.green} strokeWidth={3} opacity={0.95} />
      {Array.from({length: cards}).map((_, i) => (
        <g key={i} transform={`translate(0 ${-140 + i * 90})`}>
          <rect x={-56} y={-26} width={112} height={56} rx={6} fill="#1e2347" stroke={C.green} strokeWidth={3} />
          <circle cx={-18} cy={2} r={20} fill="#10152f" stroke={OUT} strokeWidth={3} />
          <g transform={`translate(-18 2) rotate(${f * 16})`}>
            {[0, 120, 240].map((a) => <path key={a} d="M0 0 Q10 -12 0 -18 Q-8 -10 0 0" fill={C.green} transform={`rotate(${a})`} />)}
          </g>
          <circle cx={34} cy={2} r={8} fill={C.green} opacity={0.5 + 0.5 * Math.sin(f * 0.3 + i)} />
        </g>
      ))}
      <circle cx={0} cy={160} r={14} fill={C.green} stroke={OUT} strokeWidth={4} />
      {label && <Label y={196} size={20} color="#9ec">{label}</Label>}
    </At>
  );
};

export const Desk: React.FC<{x: number; y?: number; w?: number}> = ({x, y = 900, w = 520}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-w / 2} y={-110} width={w} height={26} rx={6} fill="#b9804e" {...st} />
    <rect x={-w / 2 + 20} y={-84} width={20} height={84} fill="#8a5a33" {...st} />
    <rect x={w / 2 - 40} y={-84} width={20} height={84} fill="#8a5a33" {...st} />
  </g>
);

export const Rack3: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <rect x={-70} y={-200} width={140} height={400} rx={8} fill="#232a4a" {...st} />
      {Array.from({length: 7}).map((_, r) => (
        <g key={r}>
          <rect x={-56} y={-186 + r * 52} width={112} height={40} rx={4} fill="#2f3866" stroke={OUT} strokeWidth={3} />
          {[0, 1, 2].map((c) => <circle key={c} cx={-36 + c * 22} cy={-166 + r * 52} r={5} fill={Math.sin(f * 0.22 + r * 1.9 + c * 2.1) > 0 ? C.green : '#456'} />)}
        </g>
      ))}
    </At>
  );
};

/* ---------------- Data / graphics ---------------- */
export const NeuralNet: React.FC<PP & {layers?: number[]; w?: number; h?: number}> = ({layers = [3, 5, 5, 2], w = 700, h = 420, ...p}) => {
  const f = useCurrentFrame();
  const px = (l: number) => -w / 2 + (w / (layers.length - 1)) * l;
  const py = (l: number, i: number) => -h / 2 + (h / (layers[l] + 1)) * (i + 1);
  return (
    <At {...p}>
      {layers.slice(0, -1).map((n, l) =>
        Array.from({length: n}).map((_, i) =>
          Array.from({length: layers[l + 1]}).map((__, j) => {
            const pulse = (f * 0.03 + l * 0.25 + (i + j) * 0.07) % 1;
            return (
              <g key={`${l}${i}${j}`}>
                <line x1={px(l)} y1={py(l, i)} x2={px(l + 1)} y2={py(l + 1, j)} stroke={C.green} strokeWidth={2.5} opacity={0.35} />
                <circle cx={px(l) + (px(l + 1) - px(l)) * pulse} cy={py(l, i) + (py(l + 1, j) - py(l, i)) * pulse} r={5} fill={C.greenGlow} />
              </g>
            );
          }),
        ),
      )}
      {layers.map((n, l) =>
        Array.from({length: n}).map((_, i) => (
          <circle key={`${l}-${i}`} cx={px(l)} cy={py(l, i)} r={20 + 3 * Math.sin(f * 0.15 + l + i)} fill="#10152f" stroke={C.green} strokeWidth={5} />
        )),
      )}
    </At>
  );
};

export const BarChart: React.FC<PP & {values?: number[]; color?: string; w?: number; h?: number; grow?: number; arrow?: boolean; fall?: boolean}> = ({values = [0.2, 0.3, 0.45, 0.6, 0.8, 1], color = C.green, w = 560, h = 340, grow = 40, arrow = true, fall = false, ...p}) => {
  const f = useCurrentFrame();
  const n = values.length;
  const bw = w / n - 14;
  return (
    <At {...p}>
      <rect x={-w / 2 - 30} y={-h - 30} width={w + 60} height={h + 70} rx={14} fill="#fffaf0" {...st} />
      {values.map((v, i) => {
        const k = tween(f, i * 5, i * 5 + grow, 0, 1);
        const hh = h * v * k;
        return <rect key={i} x={-w / 2 + i * (w / n) + 4} y={-hh} width={bw} height={hh} rx={6} fill={fall ? C.red : color} {...st} strokeWidth={5} />;
      })}
      {arrow && (
        <g opacity={tween(f, 20, 40, 0, 1)}>
          <path d={fall ? `M${-w / 2} ${-h * 0.9} L${w / 2 - 20} ${-h * 0.1}` : `M${-w / 2} ${-h * 0.1} L${w / 2 - 20} ${-h * 0.92}`} stroke={fall ? C.red : C.greenDark} strokeWidth={12} fill="none" strokeLinecap="round" />
          <path d={fall ? `M${w / 2 + 10} ${-h * 0.02} l-60 -10 l30 -45Z` : `M${w / 2 + 10} ${-h * 0.98} l-60 10 l30 45Z`} fill={fall ? C.red : C.greenDark} {...st} strokeWidth={3} />
        </g>
      )}
    </At>
  );
};

export const Globe: React.FC<PP & {r?: number}> = ({r = 220, ...p}) => {
  const f = useCurrentFrame();
  const off = (f * 1.2) % 360;
  return (
    <At {...p}>
      <circle r={r + 40} fill={C.green} opacity={0.12} />
      <circle r={r} fill="#2f7fd1" {...st} />
      <clipPath id="gl"><circle r={r - 3} /></clipPath>
      <g clipPath="url(#gl)">
        {[0, 1, 2].map((i) => {
          const x = ((off + i * 120) % 360) / 360;
          return <ellipse key={i} cx={-r + x * r * 2.6 - r * 0.3} cy={-r * 0.3 + (i - 1) * r * 0.5} rx={r * 0.34} ry={r * 0.26} fill="#5fc27a" stroke={OUT} strokeWidth={4} />;
        })}
      </g>
      {Array.from({length: 9}).map((_, i) => {
        const a = rand(i) * Math.PI * 2, d = rand(i + 4) * (r - 30);
        return <circle key={i} cx={Math.cos(a) * d} cy={Math.sin(a) * d} r={7 + 4 * Math.sin(f * 0.2 + i)} fill={C.greenGlow} stroke={OUT} strokeWidth={3} />;
      })}
    </At>
  );
};

export const Bubble: React.FC<PP & {w?: number; h?: number; think?: boolean; tail?: number}> = ({w = 260, h = 170, think = false, tail = -1, children, ...p}) => (
  <At {...p}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={34} fill="#fff" {...st} />
    {think ? (
      <g fill="#fff" {...st} strokeWidth={5}>
        <circle cx={tail * (w / 2 - 40)} cy={h / 2 + 24} r={14} />
        <circle cx={tail * (w / 2 - 60)} cy={h / 2 + 56} r={8} />
      </g>
    ) : (
      <path d={`M${tail * 30} ${h / 2 - 3} l${tail * 18} 40 l${tail * -50} -40Z`} fill="#fff" {...st} strokeWidth={5} />
    )}
    {children}
  </At>
);

export const Bulb: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <circle r={90} fill={C.yellow} opacity={0.25 + 0.1 * Math.sin(f * 0.3)} />
      <path d="M0 -60 C-46 -60 -58 -10 -26 22 L-24 44 H24 L26 22 C58 -10 46 -60 0 -60Z" fill={C.yellow} {...st} />
      <rect x={-24} y={44} width={48} height={22} rx={6} fill="#c9ced9" {...st} />
      {[-60, -30, 0, 30, 60].map((a) => <line key={a} x1={0} y1={-90} x2={0} y2={-120} stroke={C.yellow} strokeWidth={6} strokeLinecap="round" transform={`rotate(${a} 0 -10) translate(0 ${-4 * Math.sin(f * 0.3)})`} />)}
    </At>
  );
};

export const Mug: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <rect x={-32} y={-40} width={64} height={70} rx={10} fill="#fff" {...st} />
      <path d="M32 -22 q34 0 30 22 q-4 18 -30 16" fill="none" {...st} />
      <rect x={-26} y={-34} width={52} height={14} fill="#6b3f26" />
      {[-14, 4, 20].map((dx, i) => <path key={i} d={`M${dx} -56 q-10 -16 0 -30 q10 -14 0 -26`} stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.7} transform={`translate(0 ${-((f * 0.8 + i * 14) % 30)})`} />)}
    </At>
  );
};

export const Book: React.FC<PP & {color?: string}> = ({color = C.blue, ...p}) => (
  <At {...p}>
    <rect x={-60} y={-14} width={120} height={28} rx={4} fill={color} {...st} />
    <rect x={-52} y={-8} width={100} height={16} fill="#fffaf0" stroke={OUT} strokeWidth={3} />
  </At>
);

export const Rocket: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <path d={`M-18 80 Q0 ${150 + 20 * Math.sin(f * 0.6)} 18 80Z`} fill={C.orange} {...st} strokeWidth={4} />
      <path d="M0 -110 C46 -60 46 30 30 80 H-30 C-46 30 -46 -60 0 -110Z" fill="#f2f4fb" {...st} />
      <circle cx={0} cy={-30} r={22} fill="#9fd8ff" {...st} />
      <path d="M-30 30 L-66 84 L-30 70Z M30 30 L66 84 L30 70Z" fill={C.red} {...st} />
    </At>
  );
};

export const Coin: React.FC<PP & {label?: string}> = ({label = '$', ...p}) => {
  const f = useCurrentFrame();
  const sx = Math.abs(Math.cos(f * 0.12 + (p.x + p.y) * 0.01));
  return (
    <At {...p}>
      <ellipse rx={36 * (0.25 + sx * 0.75)} ry={36} fill={C.yellow} {...st} strokeWidth={5} />
      <Label y={10} size={30} color={C.woodDark}>{label}</Label>
    </At>
  );
};

export const Crate: React.FC<PP & {label?: string; color?: string}> = ({label, color = '#d9a35e', ...p}) => (
  <At {...p}>
    <rect x={-60} y={-60} width={120} height={120} fill={color} {...st} />
    <path d="M-60 -60 L60 60 M60 -60 L-60 60" stroke="#a8743a" strokeWidth={5} />
    <rect x={-40} y={-18} width={80} height={36} fill="#fffaf0" stroke={OUT} strokeWidth={3} />
    {label && <Label y={9} size={20} color={OUT}>{label}</Label>}
  </At>
);

export const Paper: React.FC<PP & {w?: number; h?: number; lines?: number}> = ({w = 220, h = 280, lines = 6, children, ...p}) => (
  <At {...p}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={6} fill="#fffdf4" {...st} />
    {Array.from({length: lines}).map((_, i) => <line key={i} x1={-w / 2 + 24} y1={-h / 2 + 34 + i * 30} x2={w / 2 - 24 - (i % 3) * 20} y2={-h / 2 + 34 + i * 30} stroke="#b8bdd0" strokeWidth={5} strokeLinecap="round" />)}
    {children}
  </At>
);

export const Cross: React.FC<PP & {color?: string}> = ({color = C.red, ...p}) => (
  <At {...p}>
    <path d="M-40 -40 L40 40 M40 -40 L-40 40" stroke={OUT} strokeWidth={26} strokeLinecap="round" />
    <path d="M-40 -40 L40 40 M40 -40 L-40 40" stroke={color} strokeWidth={16} strokeLinecap="round" />
  </At>
);

export const Check: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-36 4 L-10 32 L40 -30" stroke={OUT} strokeWidth={26} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M-36 4 L-10 32 L40 -30" stroke={C.green} strokeWidth={16} fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </At>
);

export const Sparkles: React.FC<{x: number; y: number; n?: number; spread?: number; color?: string}> = ({x, y, n = 8, spread = 160, color = C.yellow}) => {
  const f = useCurrentFrame();
  return (
    <g transform={`translate(${x} ${y})`}>
      {Array.from({length: n}).map((_, i) => {
        const a = rand(i) * 6.283, d = spread * (0.4 + rand(i + 7) * 0.6);
        const sc = 0.5 + 0.5 * Math.abs(Math.sin(f * 0.18 + i * 1.7));
        return <path key={i} d="M0 -18 L5 -5 L18 0 L5 5 L0 18 L-5 5 L-18 0 L-5 -5Z" fill={color} stroke={OUT} strokeWidth={3} transform={`translate(${Math.cos(a) * d} ${Math.sin(a) * d}) scale(${sc})`} />;
      })}
    </g>
  );
};

export const Confetti: React.FC<{n?: number}> = ({n = 70}) => {
  const f = useCurrentFrame();
  const cols = [C.green, C.yellow, C.pink, C.blue, C.orange, C.purple];
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const x = rand(i) * 2000 - 40;
        const y = ((rand(i + 5) * 1300 + f * (5 + rand(i + 2) * 6)) % 1300) - 150;
        return <rect key={i} x={x + Math.sin(f * 0.1 + i) * 20} y={y} width={14} height={22} fill={cols[i % 6]} stroke={OUT} strokeWidth={2} transform={`rotate(${f * 6 + i * 40} ${x} ${y})`} />;
      })}
    </g>
  );
};

export const Calendar: React.FC<PP & {pages?: number}> = ({pages = 6, ...p}) => {
  const f = useCurrentFrame();
  const idx = Math.floor(f / 7) % pages;
  const fl = (f % 7) / 7;
  return (
    <At {...p}>
      <rect x={-90} y={-100} width={180} height={200} rx={12} fill="#fff" {...st} />
      <rect x={-90} y={-100} width={180} height={50} rx={12} fill={C.red} {...st} />
      <Label y={46 - 12} size={78} color={OUT}>{idx + 1}</Label>
      <g transform={`translate(0 -100) scale(1 ${1 - fl})`}><rect x={-90} y={0} width={180} height={100} fill="#fff" opacity={0.6 * (1 - fl)} /></g>
    </At>
  );
};

export const Clock: React.FC<PP & {speed?: number}> = ({speed = 1, ...p}) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <circle r={70} fill="#fff" {...st} />
      {Array.from({length: 12}).map((_, i) => <line key={i} x1={0} y1={-60} x2={0} y2={-52} stroke={OUT} strokeWidth={4} transform={`rotate(${i * 30})`} />)}
      <line x1={0} y1={0} x2={0} y2={-48} stroke={OUT} strokeWidth={6} strokeLinecap="round" transform={`rotate(${f * 6 * speed})`} />
      <line x1={0} y1={0} x2={0} y2={-30} stroke={C.red} strokeWidth={7} strokeLinecap="round" transform={`rotate(${f * 0.5 * speed})`} />
    </At>
  );
};

export const Cube: React.FC<PP & {wire?: boolean; color?: string}> = ({wire = true, color = C.green, ...p}) => {
  const f = useCurrentFrame();
  const a = f * 0.03, b = 0.5;
  const pts = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]].map(([x, y, z]) => {
    const x1 = x * Math.cos(a) - z * Math.sin(a), z1 = x * Math.sin(a) + z * Math.cos(a);
    const y1 = y * Math.cos(b) - z1 * Math.sin(b);
    return [x1 * 80, y1 * 80];
  });
  const faces = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [2, 3, 7, 6], [0, 3, 7, 4], [1, 2, 6, 5]];
  const edges = faces.flatMap((fc) => fc.map((v, i) => [v, fc[(i + 1) % 4]]));
  return (
    <At {...p}>
      {!wire && faces.map((fc, i) => <path key={i} d={'M' + fc.map((v) => pts[v].join(',')).join(' L') + 'Z'} fill={color} opacity={0.35 + i * 0.1} stroke={OUT} strokeWidth={4} strokeLinejoin="round" />)}
      {wire && edges.map((e, i) => <line key={i} x1={pts[e[0]][0]} y1={pts[e[0]][1]} x2={pts[e[1]][0]} y2={pts[e[1]][1]} stroke={color} strokeWidth={5} strokeLinecap="round" />)}
    </At>
  );
};

export const Plane: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-110 0 Q-110 -26 -70 -26 H80 Q120 -26 130 0 Q120 24 80 24 H-70 Q-110 24 -110 0Z" fill="#f2f4fb" {...st} />
    <path d="M-10 -26 L-50 -90 H-20 L40 -26Z M-10 24 L-50 88 H-20 L40 24Z" fill="#c9d3ee" {...st} />
    <path d="M-110 -10 L-136 -50 H-110 L-84 -26Z" fill={C.red} {...st} />
    {[-40, -10, 20, 50].map((x) => <circle key={x} cx={x} cy={-6} r={7} fill="#9fd8ff" stroke={OUT} strokeWidth={3} />)}
  </At>
);

export const Car: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <path d="M-130 20 V-10 Q-130 -26 -110 -28 L-70 -34 L-40 -78 H60 L100 -34 Q130 -30 130 -6 V20Z" fill={C.blue} {...st} />
      <path d="M-34 -34 L-18 -68 H20 V-34Z M30 -34 V-68 H52 L80 -34Z" fill="#cfe8ff" stroke={OUT} strokeWidth={4} />
      {[-72, 72].map((x) => <g key={x} transform={`translate(${x} 22)`}><circle r={28} fill="#2b2f4a" {...st} /><circle r={10} fill="#c9ced9" /><line x1={0} y1={-22} x2={0} y2={22} stroke="#c9ced9" strokeWidth={4} transform={`rotate(${f * 18})`} /></g>)}
      {[0, 1, 2].map((i) => <path key={i} d={`M0 -90 q${60 + i * 50} -50 ${100 + i * 90} 0`} stroke={C.greenGlow} strokeWidth={5} fill="none" strokeLinecap="round" opacity={0.2 + 0.7 * Math.abs(Math.sin(f * 0.15 - i * 0.7))} />)}
    </At>
  );
};

export const Robot: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <line x1={0} y1={-110} x2={0} y2={-84} stroke={OUT} strokeWidth={6} />
      <circle cy={-118} r={12} fill={C.green} {...st} strokeWidth={4} />
      <rect x={-70} y={-86} width={140} height={110} rx={26} fill="#dfe4f3" {...st} />
      {[-30, 30].map((x) => <circle key={x} cx={x} cy={-36} r={15} fill={C.green} stroke={OUT} strokeWidth={4} opacity={0.6 + 0.4 * Math.abs(Math.sin(f * 0.13))} />)}
      <path d="M-26 0 Q0 16 26 0" stroke={OUT} strokeWidth={5} fill="none" strokeLinecap="round" />
      <rect x={-50} y={34} width={100} height={90} rx={18} fill="#c9d3ee" {...st} />
    </At>
  );
};

export const ChatUI: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  const dots = Math.floor(f / 6) % 4;
  return (
    <At {...p}>
      <rect x={-250} y={-200} width={500} height={400} rx={20} fill="#fff" {...st} />
      <rect x={-210} y={-160} width={260} height={60} rx={22} fill="#e6ebff" stroke={OUT} strokeWidth={4} />
      <rect x={-50} y={-70} width={260} height={90} rx={22} fill={C.green} stroke={OUT} strokeWidth={4} opacity={tween(f, 8, 16, 0, 1)} />
      {[0, 1, 2].map((i) => <circle key={i} cx={-176 + i * 26} cy={-130} r={7} fill={i < dots ? OUT : '#b8bdd0'} />)}
      {[0, 1].map((i) => <line key={i} x1={-10} y1={-44 + i * 30} x2={170 - i * 50} y2={-44 + i * 30} stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={tween(f, 14 + i * 6, 22 + i * 6, 0, 1)} />)}
      <rect x={-210} y={130} width={420} height={44} rx={22} fill="#eef1fb" stroke={OUT} strokeWidth={4} />
    </At>
  );
};

export const CodeWindow: React.FC<PP & {w?: number; h?: number}> = ({w = 480, h = 320, ...p}) => {
  const f = useCurrentFrame();
  const lines = [200, 320, 260, 380, 150, 300, 220, 340];
  return (
    <At {...p}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={14} fill="#10152f" {...st} />
      <rect x={-w / 2} y={-h / 2} width={w} height={44} rx={14} fill="#2b2f4a" {...st} />
      {[C.red, C.yellow, C.green].map((c, i) => <circle key={i} cx={-w / 2 + 28 + i * 28} cy={-h / 2 + 22} r={8} fill={c} />)}
      {lines.map((l, i) => {
        const k = tween(f, i * 5, i * 5 + 14, 0, 1);
        return <line key={i} x1={-w / 2 + 30 + (i % 3) * 26} y1={-h / 2 + 80 + i * 28} x2={-w / 2 + 30 + (i % 3) * 26 + l * k * (w / 480)} y2={-h / 2 + 80 + i * 28} stroke={[C.green, '#7ab8ff', '#ffb35c', '#c9a0ff'][i % 4]} strokeWidth={9} strokeLinecap="round" />;
      })}
    </At>
  );
};

export const Whiteboard: React.FC<PP & {w?: number; h?: number}> = ({w = 640, h = 380, children, ...p}) => (
  <At {...p}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={10} fill="#fafcff" stroke={OUT} strokeWidth={8} />
    <rect x={-w / 2 + 20} y={h / 2} width={w - 40} height={16} fill="#c9ced9" {...st} strokeWidth={4} />
    {children}
  </At>
);

export const Cap: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-70 0 L0 -30 L70 0 L0 30Z" fill={OUT} stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
    <path d="M-38 16 V46 Q0 64 38 46 V16 L0 30Z" fill="#2c3260" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
    <path d="M70 0 V44" stroke={C.yellow} strokeWidth={6} />
    <circle cx={70} cy={48} r={7} fill={C.yellow} stroke={OUT} strokeWidth={3} />
  </At>
);

export const Trophy: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-50 -70 H50 V-20 Q50 30 0 40 Q-50 30 -50 -20Z" fill={C.yellow} {...st} />
    <path d="M-50 -56 q-40 0 -36 30 q4 24 40 24 M50 -56 q40 0 36 30 q-4 24 -40 24" fill="none" {...st} />
    <rect x={-14} y={40} width={28} height={34} fill={C.yellow} {...st} />
    <rect x={-44} y={72} width={88} height={22} rx={6} fill={C.woodDark} {...st} />
  </At>
);

export const Podium: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-80 -90 H80 L100 140 H-100Z" fill="#2b2f4a" {...st} />
    <rect x={-74} y={-96} width={148} height={14} fill={C.green} {...st} strokeWidth={4} />
    <line x1={20} y1={-110} x2={20} y2={-200} stroke="#c9ced9" strokeWidth={6} />
    <ellipse cx={20} cy={-208} rx={14} ry={20} fill="#2b2f4a" {...st} strokeWidth={4} />
  </At>
);

export const Phone: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <rect x={-26} y={-46} width={52} height={92} rx={10} fill="#2b2f4a" {...st} strokeWidth={4} />
      <rect x={-20} y={-38} width={40} height={72} rx={4} fill="#fff" opacity={0.6 + 0.4 * Math.abs(Math.sin(f * 0.8))} />
    </At>
  );
};

export const Bell: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p} rot={Math.sin(f * 0.6) * 12}>
      <path d="M-50 40 Q-50 -50 0 -56 Q50 -50 50 40Z" fill={C.yellow} {...st} />
      <rect x={-60} y={38} width={120} height={14} rx={6} fill={C.yellow} {...st} />
      <circle cy={64} r={12} fill={C.woodDark} {...st} strokeWidth={4} />
    </At>
  );
};

export const Boulder: React.FC<PP> = (p) => (
  <At {...p}>
    <path d="M-80 40 Q-96 -40 -30 -70 Q50 -90 84 -20 Q100 36 60 50Z" fill="#9aa0b4" {...st} />
    <path d="M-30 -20 q20 -16 40 0 M10 20 q20 -10 36 4" stroke="#7a8098" strokeWidth={6} fill="none" strokeLinecap="round" />
  </At>
);

export const Plant: React.FC<PP & {grow?: number}> = ({grow = 1, ...p}) => (
  <At {...p}>
    <path d="M-50 40 L50 40 L36 110 H-36Z" fill="#c0563a" {...st} />
    <path d={`M0 40 Q-6 ${40 - 80 * grow} 0 ${40 - 150 * grow}`} stroke={C.greenDark} strokeWidth={10} fill="none" strokeLinecap="round" />
    <g transform={`translate(0 ${40 - 150 * grow}) scale(${grow})`}>
      <path d="M0 0 Q-60 -40 -80 10 Q-30 20 0 0Z M0 0 Q60 -50 90 -2 Q40 24 0 0Z M0 0 Q-10 -70 20 -90 Q40 -40 0 0Z" fill={C.green} {...st} strokeWidth={5} />
    </g>
  </At>
);

export const Flag: React.FC<PP> = (p) => {
  const f = useCurrentFrame();
  return (
    <At {...p}>
      <line x1={0} y1={0} x2={0} y2={-180} stroke={OUT} strokeWidth={8} strokeLinecap="round" />
      <path d={`M0 -180 q40 ${-14 + 8 * Math.sin(f * 0.3)} 80 0 q40 ${14 - 8 * Math.sin(f * 0.3)} 80 0 V-110 q-40 14 -80 0 q-40 -14 -80 0Z`} transform="translate(0 0)" fill={C.green} {...st} strokeWidth={5} />
    </At>
  );
};

export const Tree: React.FC<PP> = (p) => (
  <At {...p}>
    <rect x={-16} y={-20} width={32} height={120} fill={C.wood} {...st} />
    <circle cy={-70} r={80} fill="#4fb37b" {...st} />
    <circle cx={-50} cy={-40} r={50} fill="#5fc27a" {...st} />
    <circle cx={52} cy={-44} r={46} fill="#5fc27a" {...st} />
  </At>
);

export const Ball: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={12} fill="#fff" {...st} strokeWidth={4} />
  </g>
);

export const Paddle: React.FC<PP> = (p) => (
  <At {...p}>
    <ellipse cy={-40} rx={44} ry={50} fill={C.red} {...st} />
    <rect x={-10} y={0} width={20} height={64} rx={8} fill={C.wood} {...st} />
  </At>
);

export const Qmark: React.FC<PP & {color?: string}> = ({color = C.green, ...p}) => (
  <At {...p}>
    <text textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={120} fill={color} stroke={OUT} strokeWidth={6} paintOrder="stroke" y={40}>?</text>
  </At>
);

export const Banner: React.FC<PP & {text: string; w?: number; color?: string; size?: number}> = ({text, w = 480, color = C.green, size = 46, ...p}) => (
  <At {...p}>
    <rect x={-w / 2} y={-44} width={w} height={88} rx={20} fill={color} {...st} />
    <Label y={size / 3} size={size} color="#fff">{text}</Label>
  </At>
);

export const Counter: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-380} y={-40} width={760} height={30} rx={8} fill="#f4e9d2" {...st} />
    <rect x={-370} y={-10} width={740} height={120} fill="#2f8f8a" {...st} />
  </g>
);

export const Booth: React.FC<{x: number; y?: number; w?: number}> = ({x, y = 900, w = 900}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-w / 2} y={-130} width={w} height={20} rx={8} fill="#f4e9d2" {...st} />
    <rect x={-20} y={-110} width={40} height={110} fill="#8a5a33" {...st} />
    <ellipse cx={0} cy={0} rx={120} ry={14} fill="#8a5a33" {...st} />
  </g>
);

export const Plate: React.FC<PP> = (p) => (
  <At {...p}>
    <ellipse rx={44} ry={12} fill="#fff" {...st} strokeWidth={4} />
    <ellipse rx={26} ry={6} fill="#e7ebf5" />
  </At>
);

export const Ripple: React.FC<{x: number; y: number; color?: string; max?: number}> = ({x, y, color = C.green, max = 900}) => {
  const f = useCurrentFrame();
  return (
    <g transform={`translate(${x} ${y})`} fill="none" stroke={color} strokeWidth={8}>
      {[0, 1, 2].map((i) => {
        const k = ((f * 0.02 + i / 3) % 1);
        return <circle key={i} r={k * max} opacity={1 - k} />;
      })}
    </g>
  );
};

export const Lightning: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => {
  const f = useCurrentFrame();
  const on = f % 40 < 6;
  return on ? (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path d="M0 0 L-40 100 L0 90 L-30 200 L60 70 L12 80Z" fill={C.yellow} {...st} />
    </g>
  ) : null;
};

export const Storm: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill="#59607f" {...st}>
    <ellipse cx={0} cy={0} rx={140} ry={50} />
    <ellipse cx={-80} cy={-30} rx={80} ry={56} />
    <ellipse cx={60} cy={-50} rx={90} ry={62} />
  </g>
);

export const Gear: React.FC<PP & {color?: string}> = ({color = C.gray, ...p}) => {
  const f = useCurrentFrame();
  return (
    <At {...p} rot={f * 2}>
      {Array.from({length: 8}).map((_, i) => <rect key={i} x={-14} y={-78} width={28} height={30} fill={color} stroke={OUT} strokeWidth={5} transform={`rotate(${i * 45})`} />)}
      <circle r={60} fill={color} {...st} />
      <circle r={22} fill="#fff" {...st} strokeWidth={5} />
    </At>
  );
};

export const wobble = wob;
export const clamp = clamp01;
