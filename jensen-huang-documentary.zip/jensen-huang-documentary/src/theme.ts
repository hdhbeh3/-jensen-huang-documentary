// Global art direction: one palette, one outline colour, one outline weight.
export const W = 1920;
export const H = 1080;
export const FPS = 24;
export const GROUND = 900; // y of the floor line for characters

export const OUT = '#14172e'; // universal outline colour
export const STROKE = 6; // universal outline weight

export const C = {
  green: '#76b900',
  greenDark: '#4c7a00',
  greenGlow: '#b6f23a',
  navy: '#14172e',
  ink: '#1d2140',
  skyTop: '#7ec8ff',
  skyBottom: '#d9f1ff',
  cream: '#fff4de',
  paper: '#fffaf0',
  gray: '#8d93a8',
  grayLight: '#d3d7e4',
  grayDark: '#4a4f66',
  red: '#e5484d',
  orange: '#ff9f43',
  yellow: '#ffd23f',
  blue: '#3b82f6',
  purple: '#7c5cff',
  pink: '#ff7aa2',
  wood: '#b9804e',
  woodDark: '#8a5a33',
  skin: '#eab98c',
};

export const FONT = "'Trebuchet MS', 'Segoe UI', Arial, sans-serif";
