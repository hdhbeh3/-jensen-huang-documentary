import React from 'react';
import {Composition} from 'remotion';
import {Documentary} from './Documentary';
import {FPS, H, W} from './theme';
import {TOTAL_FRAMES} from './timeline';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="JensenHuangDocumentary"
    component={Documentary}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={W}
    height={H}
  />
);
