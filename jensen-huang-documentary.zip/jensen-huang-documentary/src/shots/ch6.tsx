// CHAPTER 6 — GeForce 256, CUDA and AlexNet
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgBlueprint, BgClassroom, BgGlow, BgOffice, BgRoom} from '../components/Backgrounds';
import {At, Banner, Car, Card, Check, Chip, CodeWindow, Crate, Cube, Label, Monitor, NeuralNet, Paper, Qmark, Ripple, Sparkles, Tower, Bubble} from '../components/Props';
import {C, FONT, OUT} from '../theme';
import {lerp, pop, rand, tween} from '../lib/anim';

const GeForce: React.FC = () => {
  const {f, p} = useP();
  const k = pop(f, 18, 14);
  return (
    <g>
      <BgGlow p={p} />
      <Ripple x={960} y={460} max={700} />
      <Card x={960} y={470} s={1.7} label="GeForce 256" />
      <g transform={`translate(960 860) scale(${k})`}>
        <text textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={190} fill={C.green} stroke={OUT} strokeWidth={10} paintOrder="stroke">GPU</text>
      </g>
      <Sparkles x={960} y={470} n={12} spread={520} color={C.greenGlow} />
    </g>
  );
};

const WireToShaded: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgBlueprint p={p} />
      <Cube x={540} y={500} s={2.2} wire />
      <path d="M800 500 H1100 M1060 460 L1110 500 L1060 540" stroke={C.green} strokeWidth={14} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <Cube x={1380} y={500} s={2.2} wire={false} color={C.green} />
      <Stickman look="jensenYoung" x={960} y={900} scale={1.7} pose="armsOpen" expr="happy" />
    </g>
  );
};

const Landscape: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#2f3572" />
      <Monitor x={960} y={470} w={760} h={460}>
        <rect x={0} y={0} width={732} height={432} fill="#7ec8ff" />
        <circle cx={600} cy={90} r={46} fill="#ffe27a" />
        <path d="M0 300 Q180 170 330 280 T732 250 V432 H0Z" fill="#4fb37b" stroke={OUT} strokeWidth={5} />
        <path d="M0 360 Q300 300 732 350 V432 H0Z" fill="#3f9657" />
        <At x={160 + Math.sin(f * 0.05) * 20} y={300} s={0.7}><circle cy={-60} r={50} fill="#4fb37b" stroke={OUT} strokeWidth={5} /><rect x={-10} y={-20} width={20} height={70} fill={C.wood} /></At>
      </Monitor>
      <Stickman look="gamer" x={400} y={900} scale={1.85} pose="armsUp" expr="surprised" seed={1} />
      <Stickman look="gamer2" x={1520} y={900} scale={1.85} flip pose="armsUp" expr="surprised" seed={2} />
    </g>
  );
};

const MathMinds: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgBlueprint p={p} />
      {Array.from({length: 30}).map((_, i) => <text key={i} x={140 + (i % 10) * 180} y={150 + Math.floor(i / 10) * 110 + Math.sin(f * 0.05 + i) * 8} fontFamily={FONT} fontSize={44} fontWeight={800} fill="#7ab8ff" opacity={0.35 + 0.3 * Math.sin(f * 0.1 + i)}>{Math.floor(rand(i) * 9)}</text>)}
      <Stickman look="researcher" x={620} y={900} scale={2} pose="think" expr="thinking" />
      <Bubble x={1200} y={400} w={520} h={320} think tail={-1} delay={10}>
        {Array.from({length: 16}).map((_, i) => <rect key={i} x={-180 + (i % 4) * 96} y={-110 + Math.floor(i / 4) * 70} width={70} height={50} rx={8} fill={Math.sin(f * 0.2 - i * 0.6) > 0 ? C.green : '#cfd6ea'} stroke={OUT} strokeWidth={4} />)}
      </Bubble>
    </g>
  );
};

const CudaTalk: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <CodeWindow x={1180} y={440} w={760} h={480} />
      <Banner x={1180} y={140} text="CUDA" w={300} size={56} delay={14} />
      <Chip x={1700} y={730} s={0.6} />
      <Stickman look="jensenCEO" x={440} y={900} scale={1.95} pose="point" motion="talk" expr="happy" speaking />
    </g>
  );
};

const ManyWorkers: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgBlueprint p={p} />
      <Stickman look="engineer" x={330} y={900} scale={2.1} pose="carry" expr="worried" motion="pace" speed={0.6} />
      {[0, 1, 2].map((i) => <Crate key={i} x={330 + 40 * (i - 1)} y={380 - i * 10} s={0.6} />)}
      {Array.from({length: 15}).map((_, i) => {
        const col = i % 5, row = Math.floor(i / 5);
        const looks = ['engineer', 'engineer2', 'student', 'researcher', 'fan'] as const;
        return <Stickman key={i} look={looks[(i + row) % 5]} x={820 + col * 220} y={560 + row * 170} scale={0.8} pose="idle" motion="type" expr="happy" seed={i} />;
      })}
      <Label x={1270} y={1030} size={40} color="#9ec">Many small workers, all at once</Label>
    </g>
  );
};

const Lecture: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgClassroom p={p} tone={0} />
      <CodeWindow x={960} y={400} w={620} h={360} />
      <Stickman look="professor" x={430} y={900} scale={1.9} pose="point" motion="talk" expr="happy" />
      {(['student', 'student2', 'researcher', 'engineer2'] as const).map((l, i) => (
        <g key={l}>
          <rect x={900 + i * 240} y={780} width={190} height={20} rx={8} fill="#8a5a33" stroke={OUT} strokeWidth={6} />
          <Stickman look={l} x={1000 + i * 240} y={900} scale={1.5} flip pose="sit" motion="type" expr={i % 2 ? 'surprised' : 'happy'} seed={i} />
        </g>
      ))}
    </g>
  );
};

const AlexNetLab: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#2b2f5a" />
      <Tower x={960} y={640} s={1.5} cards={2} />
      <Banner x={960} y={110} text="AlexNet" w={420} size={60} delay={12} />
      <Stickman look="student2" x={520} y={900} scale={1.9} pose="point" expr="determined" />
      <Stickman look="researcher" x={1400} y={900} scale={1.9} flip pose="point" expr="determined" seed={2} />
      <Stickman look="professor" x={1700} y={900} scale={1.8} flip pose="think" expr="thinking" seed={3} />
      <Sparkles x={960} y={620} n={8} spread={330} color={C.green} />
    </g>
  );
};

const Cat: React.FC<{x: number; y: number}> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`} stroke={OUT} strokeWidth={5} strokeLinejoin="round">
    <path d="M-50 -20 L-40 -62 L-14 -34Z M50 -20 L40 -62 L14 -34Z" fill="#f0a35c" />
    <circle r={52} fill="#f0a35c" />
    <circle cx={-18} cy={-6} r={6} fill={OUT} /><circle cx={18} cy={-6} r={6} fill={OUT} />
    <path d="M-10 14 Q0 22 10 14" fill="none" strokeLinecap="round" />
  </g>
);

const ImageContest: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const x = 250 + (i % 3) * 270, y = 270 + Math.floor(i / 3) * 270;
        return (
          <g key={i}>
            <rect x={x - 110} y={y - 110} width={220} height={220} rx={16} fill="#fffaf0" stroke={OUT} strokeWidth={6} />
            {i % 3 === 0 ? <Cat x={x} y={y} /> : i % 3 === 1 ? <At x={x} y={y + 14} s={0.6}><Car x={0} y={0} /></At> : <At x={x} y={y + 40} s={0.7}><circle cy={-50} r={56} fill="#4fb37b" stroke={OUT} strokeWidth={6} /><rect x={-12} y={-6} width={24} height={64} fill={C.wood} stroke={OUT} strokeWidth={5} /></At>}
            <Check x={x + 70} y={y + 70} s={0.7} delay={20 + i * 8} />
          </g>
        );
      })}
      <rect x={1130} y={170} width={640} height={640} rx={18} fill="#10152f" stroke={C.green} strokeWidth={7} />
      {[0.28, 0.34, 0.4, 0.5, 1].map((v, i) => {
        const k = tween(f, 10 + i * 6, 50 + i * 6, 0, 1);
        return <rect key={i} x={1190 + i * 108} y={760 - 520 * v * k} width={80} height={520 * v * k} rx={6} fill={i === 4 ? C.green : C.gray} stroke={OUT} strokeWidth={5} />;
      })}
    </g>
  );
};

const Shockwave: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} />
      <NeuralNet x={960} y={500} s={1.4} layers={[4, 6, 6, 3]} />
      <Ripple x={960} y={500} max={1000} />
      <Chip x={960} y={500} s={0.9} />
      <Stickman look="jensenCEO" x={300} y={940} scale={1.7} pose={['hold', 'armsUp']} expr="surprised" />
    </g>
  );
};

export const CH6 = [GeForce, WireToShaded, Landscape, MathMinds, CudaTalk, ManyWorkers, Lecture, AlexNetLab, ImageContest, Shockwave];
