// CHAPTER 2 — Childhood and education
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgBlueprint, BgCampus, BgClassroom, BgDiner, BgKentucky, BgRoom, BgSky, BgTropic} from '../components/Backgrounds';
import {At, Ball, Book, Bulb, Cap, Chip, Confetti, Counter, Desk, Mug, Paddle, Plane, Plate, Qmark, Sparkles, Whiteboard} from '../components/Props';
import {C, OUT} from '../theme';
import {lerp, pop, tween, wob} from '../lib/anim';

const Suitcase: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke={OUT} strokeWidth={6} strokeLinejoin="round">
    <path d="M-16 -62 V-78 H16 V-62" fill="none" />
    <rect x={-46} y={-62} width={92} height={70} rx={10} fill="#c0563a" />
    <rect x={-46} y={-30} width={92} height={10} fill="#e8b24a" />
  </g>
);

const Home: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgTropic p={p} tone={3} />
      <Stickman look="mom" x={640} y={900} scale={1.9} pose="idle" expr="happy" seed={1} />
      <Stickman look="dad" x={1280} y={900} scale={1.9} pose="idle" expr="happy" flip seed={2} />
      <Stickman look="jensenChild" x={960} y={905} scale={2.7} motion="wave" expr="happy" />
      <Sparkles x={960} y={420} n={5} spread={200} />
    </g>
  );
};

const Leaving: React.FC = () => {
  const {p} = useP();
  const x = lerp(300, 1500, p);
  return (
    <g>
      <BgTropic p={p} tone={1} />
      <Plane x={lerp(-200, 2200, p)} y={220} s={0.8} />
      <Stickman look="jensenChild" x={x} y={905} scale={2.6} motion="walk" expr="neutral" pose="idle" />
      <Suitcase x={x + 120} y={905} s={1.4} />
      <Stickman look="mom" x={x - 240} y={900} scale={1.8} motion="walk" expr="sad" seed={3} />
    </g>
  );
};

const Flight: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgSky p={p} tone={0} />
      <rect x={-300} y={820} width={2600} height={400} fill="#2f7fd1" stroke={OUT} strokeWidth={6} />
      {Array.from({length: 8}).map((_, i) => <path key={i} d={`M${100 + i * 260} ${900 + (i % 2) * 70} q40 -26 80 0 t80 0`} stroke="#9fd8ff" strokeWidth={6} fill="none" strokeLinecap="round" transform={`translate(${-(f * 2) % 260} 0)`} />)}
      <path d="M100 700 Q960 80 1840 640" stroke="#fff" strokeWidth={8} fill="none" strokeDasharray="4 22" strokeLinecap="round" />
      <Plane x={lerp(300, 1500, p)} y={lerp(560, 480, p) + wob(f, 0.1, 10)} s={1.4} rot={-6} />
    </g>
  );
};

const Arrival: React.FC = () => {
  const {p, f} = useP();
  return (
    <g>
      <BgKentucky p={p} tone={0} />
      <Stickman look="jensenChild" x={620} y={910} scale={2.6} pose="idle" expr={p < 0.5 ? 'worried' : 'determined'} lookDir={[1, -0.6]} />
      <Suitcase x={500} y={910} s={1.4} />
      <Qmark x={820} y={420 + wob(f, 0.1, 10)} s={0.7} color="#fff" delay={14} />
    </g>
  );
};

const Chores: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={0} wall="#cfe8f5" floorColor="#9fb7c8" />
      <Stickman look="jensenChild" x={820} y={910} scale={2.7} motion="work" expr="determined" />
      <g transform="translate(1180 880)" stroke={OUT} strokeWidth={6} strokeLinejoin="round">
        <path d="M-60 -90 H60 L48 0 H-48Z" fill="#8fa0b8" />
        <ellipse cy={-90} rx={60} ry={14} fill="#bfe6ff" />
      </g>
      {Array.from({length: 9}).map((_, i) => <circle key={i} cx={1180 + wob(f, 0.07, 60, i * 2)} cy={780 - ((f * 2 + i * 60) % 500)} r={10 + (i % 4) * 6} fill="#fff" stroke="#9fd8ff" strokeWidth={3} opacity={0.8} />)}
      <Sparkles x={820} y={720} n={4} spread={140} color="#fff" />
    </g>
  );
};

const Study: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#3a3f7a" />
      <Desk x={1020} w={520} />
      <Book x={1020} y={770} color={C.blue} s={1.3} />
      <Book x={1190} y={770} color={C.red} s={1} />
      <g transform="translate(1250 700)"><path d="M0 70 V-40 L-40 -70 H20" stroke={OUT} strokeWidth={8} fill="none" /><path d="M-60 -70 L-10 -100 L30 -70Z" fill={C.yellow} stroke={OUT} strokeWidth={5} /></g>
      <rect x={560} y={730} width={170} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
      <Stickman look="jensenTeen" x={690} y={895} scale={2.0} pose="sit" motion="work" expr="determined" />
      <Bulb x={780} y={330} s={0.9} delay={Math.floor(p * 0) + 28} />
    </g>
  );
};

const TableTennis: React.FC = () => {
  const {f, p} = useP();
  const t = (f * 0.06) % 2;
  const dir = t < 1 ? t : 2 - t;
  return (
    <g>
      <BgClassroom p={p} tone={0} />
      <g stroke={OUT} strokeWidth={6} strokeLinejoin="round">
        <path d="M600 800 H1320 L1380 840 H540Z" fill="#2c6fd1" />
        <rect x={560} y={840} width={20} height={90} fill="#3a3f5c" />
        <rect x={1340} y={840} width={20} height={90} fill="#3a3f5c" />
        <rect x={950} y={740} width={20} height={60} fill="#e8ebf5" />
      </g>
      <Stickman look="jensenTeen" x={430} y={905} scale={2.1} pose="reach" expr="determined" motion="pace" />
      <Stickman look="roommate" x={1500} y={905} scale={2.1} pose="reach" expr="worried" flip seed={4} />
      <Ball x={lerp(640, 1290, dir)} y={720 - 140 * Math.sin(dir * Math.PI)} />
      <Paddle x={600} y={640} s={0.7} rot={40} />
    </g>
  );
};

const DishWasher: React.FC = () => {
  const {f, p} = useP();
  const n = Math.min(6, 2 + Math.floor(f / 12));
  return (
    <g>
      <BgDiner p={p} tone={0} />
      <Counter x={1400} y={800} />
      <Mug x={1250} y={760} s={0.9} />
      <Stickman look="jensenWorker" x={760} y={905} scale={2.1} pose="carry" motion="pace" expr="neutral" />
      {Array.from({length: n}).map((_, i) => <Plate key={i} x={760} y={680 - i * 14} s={1.3} />)}
      <Stickman look="mom" x={1500} y={900} scale={1.8} flip pose="idle" expr="happy" seed={9} />
    </g>
  );
};

const Graduation: React.FC = () => {
  const {f, p} = useP();
  const k = tween(f, 20, 60, 0, 1);
  return (
    <g>
      <BgCampus p={p} tone={0} />
      <Stickman look="jensenYoung" x={960} y={900} scale={2.0} motion="cheer" expr="laugh" />
      <Cap x={960 + 200 * k} y={580 - 500 * Math.sin(k * Math.PI) * 0.9 - 40 + (k >= 1 ? 0 : 0)} s={0.8} rot={k * 380} />
      <Confetti n={50} />
    </g>
  );
};

const Blueprint: React.FC = () => {
  const {f, p} = useP();
  const draw = tween(f, 6, 50, 0, 1);
  return (
    <g>
      <BgBlueprint p={p} />
      <Whiteboard x={1040} y={520} w={760} h={440}>
        <path d="M-300 -100 h160 v80 h120 v-120 h120 v200 h200" stroke={C.green} strokeWidth={10} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
        <rect x={-300} y={60} width={140} height={100} fill="none" stroke={C.blue} strokeWidth={8} strokeDasharray="12 8" />
        <circle cx={150} cy={110} r={46} fill="none" stroke={C.orange} strokeWidth={8} />
      </Whiteboard>
      <Stickman look="jensenYoung" x={400} y={900} scale={2.0} pose="point" motion="talk" expr="determined" />
      <Chip x={1650} y={280} s={0.5} delay={50} />
    </g>
  );
};

export const CH2 = [Home, Leaving, Flight, Arrival, Chores, Study, TableTennis, DishWasher, Graduation, Blueprint];
