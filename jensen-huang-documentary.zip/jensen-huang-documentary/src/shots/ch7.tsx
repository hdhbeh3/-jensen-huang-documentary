// CHAPTER 7 — The AI revolution and NVIDIA's growing influence
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {Crowd} from '../components/Crowd';
import {BgBlueprint, BgCity, BgDatacenter, BgGlow, BgRoom, BgSky, BgStage} from '../components/Backgrounds';
import {At, BarChart, Car, Card, ChatUI, Chip, Coin, Crate, Globe, Laptop, NeuralNet, Phone, Plane, Rack3, Ripple, Robot, Rocket, Sparkles, Trophy, Check} from '../components/Props';
import {C, OUT} from '../theme';
import {lerp, rand, tween, wob} from '../lib/anim';

const BigNet: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} />
      <NeuralNet x={960} y={540} s={1.7} layers={[5, 8, 8, 4]} w={900} h={520} />
      <Ripple x={960} y={540} max={800} />
    </g>
  );
};

const DataCenterWork: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgDatacenter p={p} />
      <Stickman look="engineer" x={lerp(200, 1100, p)} y={900} scale={1.8} motion="walk" pose="carry" expr="determined" />
      <Card x={lerp(200, 1100, p) + 10} y={640} s={0.4} />
      <Stickman look="engineer2" x={lerp(1800, 1000, p)} y={900} scale={1.8} flip motion="walk" pose="idle" expr="happy" seed={2} />
      <Rack3 x={1500} y={560} s={0.9} />
    </g>
  );
};

const Chatbot: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={0} wall="#e8edff" />
      <ChatUI x={960} y={470} s={1.3} />
      <Robot x={1560} y={660} s={1.5} />
      <Stickman look="student2" x={380} y={900} scale={1.9} pose="point" expr={f % 80 < 40 ? 'surprised' : 'laugh'} />
      <Sparkles x={960} y={200} n={6} spread={500} color={C.green} />
    </g>
  );
};

const Queue: React.FC = () => {
  const {f, p} = useP();
  const looks = ['investor', 'investor2', 'researcher', 'engineer', 'professor'] as const;
  return (
    <g>
      <BgCity p={p} tone={1} />
      {looks.map((l, i) => (
        <g key={l}>
          <Stickman look={l} x={260 + i * 270 + (f * 0.6) % 20} y={900} scale={1.65} motion="pace" pose="hold" expr="determined" seed={i} />
          <Coin x={260 + i * 270 + (f * 0.6) % 20} y={560} s={0.8} delay={i * 4} />
        </g>
      ))}
      <Crate x={1680} y={800} s={1.5} label="GPU" />
      <Crate x={1680} y={640} s={1.2} label="GPU" />
      <Check x={1680} y={470} s={1.1} delay={30} />
    </g>
  );
};

const Keynote: React.FC = () => {
  const {f, p, v} = useP();
  return (
    <g>
      <BgStage p={p} />
      <Chip x={1450} y={430} s={1.5} />
      <Stickman look="jensenCEO" x={820} y={885} scale={2.05} pose="point" motion="talk" expr="happy" speaking />
      <Crowd phones cheer={0.4} />
    </g>
  );
};

const AIEverywhere: React.FC = () => {
  const {f, p} = useP();
  const items = [Car, Robot, Phone, Laptop, Card, Chip];
  return (
    <g>
      <BgGlow p={p} color={C.blue} />
      <Globe x={960} y={540} r={200} />
      {items.map((I, i) => {
        const a = -f * 0.018 + (i / items.length) * Math.PI * 2;
        return <I key={i} x={960 + Math.cos(a) * 600} y={540 + Math.sin(a) * 300} s={0.55 + 0.1 * Math.sin(a)} />;
      })}
    </g>
  );
};

const Skyrocket: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgCity p={p} tone={2} />
      <BarChart x={760} y={820} s={1.4} values={[0.1, 0.18, 0.3, 0.5, 0.75, 1]} />
      <Rocket x={lerp(1200, 1500, p)} y={lerp(700, 150, p)} s={1.3} rot={20} />
      {[0, 1, 2, 3].map((i) => <Coin key={i} x={1250 + i * 150} y={820 - ((f * 4 + i * 90) % 500)} s={0.8} />)}
      <Trophy x={1700} y={780} s={1.2} />
    </g>
  );
};

const Fans: React.FC = () => {
  const {f, p} = useP();
  const flash = f % 36 < 3;
  return (
    <g>
      <BgStage p={p} />
      <Stickman look="jensenCEO" x={960} y={900} scale={2.1} pose="armsOpen" expr="happy" motion="nod" />
      {[[560, 'fan'], [1360, 'fan2'], [250, 'student2'], [1680, 'gamer']].map(([x, l], i) => (
        <g key={i}>
          <Stickman look={l as 'fan'} x={x as number} y={900} scale={1.6} flip={(x as number) > 960} pose="reach" expr="laugh" seed={i} />
          <Phone x={(x as number) + ((x as number) > 960 ? -150 : 150)} y={560} s={0.9} />
        </g>
      ))}
      {flash && <rect x={-100} y={-100} width={2200} height={1300} fill="#fff" opacity={0.55} />}
    </g>
  );
};

const Helix: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgBlueprint p={p} />
      {Array.from({length: 26}).map((_, i) => {
        const y = 100 + i * 36, a = i * 0.5 + f * 0.1;
        const x1 = 1300 + Math.sin(a) * 120, x2 = 1300 - Math.sin(a) * 120;
        return (
          <g key={i}>
            <line x1={x1} y1={y} x2={x2} y2={y} stroke="#7ab8ff" strokeWidth={4} opacity={0.6} />
            <circle cx={x1} cy={y} r={11} fill={C.green} stroke={OUT} strokeWidth={4} />
            <circle cx={x2} cy={y} r={11} fill={C.orange} stroke={OUT} strokeWidth={4} />
          </g>
        );
      })}
      <Stickman look="researcher" x={560} y={900} scale={2} pose="point" expr="surprised" />
      <Chip x={900} y={320} s={0.55} />
    </g>
  );
};

const GlobalShipping: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} color={C.blue} />
      <Globe x={960} y={560} r={260} />
      <Plane x={lerp(-100, 2000, (p * 1.2) % 1)} y={200 + 90 * Math.sin(p * 3)} s={0.9} />
      {[0, 1, 2].map((i) => <Crate key={i} x={300 + i * 110} y={820 - Math.abs(Math.sin(f * 0.1 + i)) * 20} s={0.8} label="GPU" />)}
      <Stickman look="engineer" x={1650} y={900} scale={1.8} flip motion="wave" expr="happy" />
    </g>
  );
};

const WindowView: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgCity p={p} tone={2} />
      <g fill="#0b0e24" stroke={OUT} strokeWidth={8}>
        <rect x={-100} y={-100} width={420} height={1300} />
        <rect x={1600} y={-100} width={520} height={1300} />
        <rect x={-100} y={-100} width={2200} height={170} />
        <rect x={-100} y={880} width={2200} height={400} />
      </g>
      <Stickman look="jensenCEO" x={560} y={895} scale={2} pose="think" expr="thinking" lookDir={[1, -0.3]} />
    </g>
  );
};

const Launch: React.FC = () => {
  const {f, p} = useP();
  const y = lerp(800, -300, p * p);
  return (
    <g>
      <BgSky p={p} tone={3} />
      {Array.from({length: 14}).map((_, i) => <circle key={i} cx={960 + wob(f, 0.1, 40, i)} cy={y + 150 + i * 46} r={36 + i * 3} fill="#fff" opacity={0.75 - i * 0.04} />)}
      <Rocket x={960} y={y} s={2} />
      <rect x={-300} y={900} width={2600} height={400} fill="#8dc572" stroke={OUT} strokeWidth={6} />
      <Stickman look="jensenCEO" x={420} y={950} scale={1.7} motion="cheer" expr="laugh" />
      <Stickman look="engineer" x={1500} y={950} scale={1.6} flip motion="cheer" expr="laugh" seed={2} />
    </g>
  );
};

export const CH7 = [BigNet, DataCenterWork, Chatbot, Queue, Keynote, AIEverywhere, Skyrocket, Fans, Helix, GlobalShipping, WindowView, Launch];
