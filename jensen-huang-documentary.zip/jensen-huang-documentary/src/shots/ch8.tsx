// CHAPTER 8 — The bigger lesson behind Jensen Huang's journey
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgCity, BgGlow, BgHills, BgRoom, BgSky, BgSunrise} from '../components/Backgrounds';
import {At, Boulder, Bulb, Card, Flag, Globe, Plant, Ripple, Sparkles, Tree} from '../components/Props';
import {C, OUT} from '../theme';
import {lerp, tween, wob} from '../lib/anim';

const AgesWalk: React.FC = () => {
  const {f, p} = useP();
  const looks = ['jensenChild', 'jensenTeen', 'jensenYoung', 'jensenCEO'] as const;
  const scales = [2.6, 2.1, 1.9, 1.9];
  return (
    <g>
      <BgHills p={p} tone={3} />
      <path d="M-100 900 H2100 V1000 H-100Z" fill="#d9c49a" stroke={OUT} strokeWidth={6} />
      {looks.map((l, i) => (
        <g key={l} opacity={tween(f, 6 + i * 14, 18 + i * 14, 0, 1)}>
          <Stickman look={l} x={330 + i * 420 + p * 80} y={940} scale={scales[i]} motion="walk" expr="happy" seed={i} />
        </g>
      ))}
    </g>
  );
};

const Seedling: React.FC = () => {
  const {f, p} = useP();
  const g = tween(f, 8, 70, 0.05, 1);
  return (
    <g>
      <BgSky p={p} tone={0} />
      <rect x={-300} y={820} width={2600} height={500} fill="#9a7a5e" stroke={OUT} strokeWidth={6} />
      <path d="M800 820 l30 40 l-20 30 l30 40" stroke={OUT} strokeWidth={7} fill="none" strokeLinecap="round" />
      <Plant x={960} y={760} s={1.3} grow={g} />
      <Stickman look="jensenYoung" x={500} y={820} scale={1.9} pose="point" expr="happy" />
      <Sparkles x={960} y={420} n={8} spread={260} />
    </g>
  );
};

const Summit: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgSunrise p={p} />
      <path d="M-100 1000 L560 520 L760 640 L1060 220 L1500 700 L1760 560 L2200 1000Z" fill="#6b5aa8" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
      <path d="M1060 220 L940 330 L1010 320 L1060 390 L1120 320 L1190 330Z" fill="#fff" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
      <Flag x={1190} y={300} s={0.7} />
      <Stickman look="jensenCEO" x={1060} y={236} scale={0.95} pose="armsUp" expr="laugh" />
      <Card x={420} y={860} s={0.4} label="NV1" />
    </g>
  );
};

const Uphill: React.FC = () => {
  const {f, p} = useP();
  const t = tween(f, 0, 100, 0, 1, (x) => x);
  const x = lerp(420, 1400, t), y = lerp(860, 420, t);
  return (
    <g>
      <BgHills p={p} tone={0} />
      <path d="M-100 940 L1560 380 L2100 380 V1100 H-100Z" fill="#a98a6a" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
      <Boulder x={x + 120} y={y - 56} s={0.9} />
      <Stickman look="jensenYoung" x={x - 20} y={y} scale={1.6} pose="reach" expr="determined" motion="pace" />
      {t > 0.95 && <Sparkles x={1560} y={300} n={8} spread={200} />}
    </g>
  );
};

const BigIdea: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} />
      <Stickman look="jensenCEO" x={960} y={910} scale={2.1} pose="think" expr={f < 36 ? 'thinking' : 'happy'} />
      <Bulb x={960} y={260} s={1.6} delay={36} />
      <Sparkles x={960} y={260} n={12} spread={420} color={C.yellow} />
    </g>
  );
};

const Founders: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={3} wall="#fff0d6" />
      <Stickman look="chris" x={620} y={900} scale={1.95} pose="both" motion="nod" expr="laugh" seed={1} />
      <Stickman look="jensenCEO" x={960} y={900} scale={2} pose="both" expr="laugh" />
      <Stickman look="curtis" x={1300} y={900} scale={1.95} pose="both" motion="nod" expr="laugh" seed={2} />
      <Sparkles x={960} y={450} n={10} spread={500} />
    </g>
  );
};

const ChildAndCEO: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgCity p={p} tone={1} />
      <Stickman look="jensenChild" x={780} y={900} scale={2.9} pose="idle" expr="happy" lookDir={[1, -0.8]} />
      <Stickman look="jensenCEO" x={1100} y={900} scale={2.05} pose="idle" expr="happy" lookDir={[-1, -0.6]} flip={false} seed={2} />
      <Sparkles x={960} y={260} n={6} spread={300} color="#fff" />
    </g>
  );
};

const Legacy: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} />
      <Ripple x={1150} y={460} max={900} />
      <Globe x={1150} y={460} r={250} />
      <Stickman look="jensenCEO" x={520} y={940} scale={2.1} pose="point" expr="happy" />
    </g>
  );
};

const Farewell: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgSunrise p={p} />
      <rect x={-300} y={900} width={2600} height={400} fill="#3f9657" stroke={OUT} strokeWidth={6} />
      <Tree x={250} y={900} s={1.6} />
      <Tree x={1750} y={900} s={1.3} />
      <Stickman look="jensenCEO" x={960} y={930} scale={2.2} motion="wave" expr="happy" />
    </g>
  );
};

export const CH8 = [AgesWalk, Seedling, Summit, Uphill, BigIdea, Founders, ChildAndCEO, Legacy, Farewell];
