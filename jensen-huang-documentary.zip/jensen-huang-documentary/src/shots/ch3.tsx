// CHAPTER 3 — The founding of NVIDIA with Chris Malachowsky and Curtis Priem
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgDiner, BgHills, BgOffice, BgRoom, BgSunrise, BgCity} from '../components/Backgrounds';
import {At, BarChart, Booth, Calendar, Chip, Clock, Coin, Cube, Desk, Label, Monitor, Mug, Paper, Qmark, Sparkles, Whiteboard} from '../components/Props';
import {C, OUT} from '../theme';
import {lerp, pop, tween, wob} from '../lib/anim';

const NameTag: React.FC<{x: number; y: number; text: string; delay: number}> = ({x, y, text, delay}) => (
  <At x={x} y={y} delay={delay}>
    <rect x={-190} y={-38} width={380} height={76} rx={18} fill="#fff" stroke={OUT} strokeWidth={6} />
    <rect x={-190} y={-38} width={14} height={76} rx={6} fill={C.green} />
    <Label y={11} size={32} color={OUT}>{text}</Label>
  </At>
);

const DinerTalk: React.FC = () => {
  const {f, p, v} = useP();
  return (
    <g>
      <BgDiner p={p} tone={v % 2 ? 0 : 2} />
      <Stickman look="curtis" x={960} y={900} scale={1.8} pose="sit" expr="happy" seed={3} />
      <Stickman look="jensenYoung" x={600} y={900} scale={1.85} pose="sit" motion="talk" speaking expr="happy" />
      <Stickman look="chris" x={1320} y={900} scale={1.85} pose="sit" flip motion="nod" expr="thinking" seed={2} />
      <Booth x={960} y={900} w={1000} />
      <Mug x={700} y={740} s={0.9} />
      <Mug x={1230} y={740} s={0.9} />
    </g>
  );
};

const Napkin: React.FC = () => {
  const {f, p} = useP();
  const draw = tween(f, 4, 56, 0, 1);
  return (
    <g>
      <BgDiner p={p} tone={2} />
      <rect x={-300} y={700} width={2600} height={500} fill="#f4e9d2" stroke={OUT} strokeWidth={6} />
      <Mug x={1560} y={760} s={1.6} />
      <Paper x={900} y={600} w={760} h={560} lines={0} rot={-5}>
        <rect x={-360} y={-260} width={720} height={520} fill="none" />
        <path d="M-260 -80 h120 v-80 h120 v160 h120 v-100 h120 v100 h60" stroke="#2c6fd1" strokeWidth={12} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
        <rect x={-230} y={60} width={260} height={150} rx={14} fill="none" stroke="#2c6fd1" strokeWidth={10} strokeDasharray="1" pathLength={1} strokeDashoffset={1 - tween(f, 30, 70, 0, 1)} />
        <circle cx={200} cy={140} r={60} fill="none" stroke={C.green} strokeWidth={10} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - tween(f, 50, 80, 0, 1)} />
      </Paper>
    </g>
  );
};

const Trio: React.FC = () => {
  const {p, v} = useP();
  return (
    <g>
      <BgCity p={p} tone={v % 2 ? 1 : 3} />
      <Stickman look="chris" x={560} y={900} scale={1.9} pose="hips" expr="happy" seed={1} />
      <Stickman look="jensenYoung" x={960} y={900} scale={1.9} pose="armsOpen" motion="nod" expr="happy" />
      <Stickman look="curtis" x={1360} y={900} scale={1.9} pose="hips" expr="happy" flip seed={2} />
      <NameTag x={560} y={380} text="Chris Malachowsky" delay={10} />
      <NameTag x={960} y={330} text="Jensen Huang" delay={26} />
      <NameTag x={1360} y={380} text="Curtis Priem" delay={42} />
    </g>
  );
};

export const Workstation: React.FC<{x: number; look: 'jensenYoung' | 'chris' | 'curtis'; seed: number}> = ({x, look, seed}) => (
  <g>
    <Desk x={x} w={400} />
    <Monitor x={x} y={650} w={260} h={170} s={0.95}>
      {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={14} y={16 + i * 26} width={80 + ((i * 53 + seed * 17) % 120)} height={9} rx={4} fill={[C.green, '#7ab8ff', '#ffb35c'][i % 3]} />)}
    </Monitor>
    <rect x={x - 340} y={760} width={150} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
    <Stickman look={look} x={x - 265} y={895} scale={1.55} pose="sit" motion="type" expr="determined" seed={seed} />
  </g>
);

const StartupOffice: React.FC = () => {
  const {p, v} = useP();
  return (
    <g>
      <BgOffice p={p} tone={v % 2 ? 2 : 0} />
      <Workstation x={480} look="chris" seed={1} />
      <Workstation x={1000} look="jensenYoung" seed={2} />
      <Workstation x={1520} look="curtis" seed={3} />
    </g>
  );
};

const HangSign: React.FC = () => {
  const {f, p} = useP();
  const rise = tween(f, 6, 40, 0, 1);
  return (
    <g>
      <BgCity p={p} tone={0} />
      <rect x={560} y={380} width={800} height={520} fill="#dfe6ff" stroke={OUT} strokeWidth={7} />
      <rect x={880} y={620} width={160} height={280} fill="#6a4128" stroke={OUT} strokeWidth={6} />
      <At x={960} y={lerp(900, 330, rise)}>
        <rect x={-260} y={-60} width={520} height={120} rx={18} fill="#10152f" stroke={C.green} strokeWidth={8} />
        <Label y={20} size={72} color={C.green}>NVIDIA</Label>
      </At>
      <Stickman look="jensenYoung" x={420} y={900} scale={1.9} pose="pointUp" expr="happy" />
      <Stickman look="chris" x={1500} y={900} scale={1.9} flip motion="cheer" expr="laugh" seed={2} />
      <Sparkles x={960} y={330} n={8} spread={360} />
    </g>
  );
};

const Vision3D: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={0} wall="#e2e8ff" />
      <Monitor x={960} y={470} w={620} h={400}>
        <rect x={0} y={0} width={592} height={372} fill="#0f1a3c" />
        <g transform="translate(296 186)"><Cube x={0} y={0} s={1.6} wire={f < 40} color={C.green} /></g>
      </Monitor>
      <Stickman look="jensenYoung" x={420} y={900} scale={1.95} pose="point" motion="talk" expr="happy" speaking />
      <Stickman look="gamer" x={1500} y={900} scale={1.8} flip pose="armsUp" expr="surprised" seed={2} />
      <Sparkles x={960} y={250} n={6} spread={420} color={C.green} />
    </g>
  );
};

const Pitch: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <Whiteboard x={780} y={440} w={620} h={340}>
        <g transform="translate(-130 0)"><Chip x={0} y={0} s={0.8} glow={false} /></g>
        <BarChart x={190} y={110} s={0.5} w={300} h={200} />
      </Whiteboard>
      <Stickman look="jensenYoung" x={330} y={900} scale={1.95} pose="point" motion="talk" speaking expr="determined" />
      <rect x={1420} y={740} width={170} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
      <Stickman look="investor" x={1500} y={895} scale={1.75} flip pose="sit" motion="nod" expr="thinking" seed={3} />
      <Stickman look="investor2" x={1740} y={895} scale={1.75} flip pose="sit" expr="neutral" seed={5} />
      {[0, 1, 2].map((i) => <Coin key={i} x={1450 + i * 100} y={470 - Math.abs(Math.sin(f * 0.12 + i)) * 30} delay={36 + i * 6} />)}
    </g>
  );
};

const Leap: React.FC = () => {
  const {f, p} = useP();
  const t = tween(f, 6, 70, 0, 1);
  return (
    <g>
      <BgHills p={p} tone={3} />
      <g stroke={OUT} strokeWidth={6} strokeLinejoin="round">
        <path d="M-200 700 H640 L560 1200 H-200Z" fill="#9a7a5e" />
        <path d="M1280 700 H2200 V1200 H1360Z" fill="#9a7a5e" />
      </g>
      <g transform="translate(1700 560)"><rect x={-70} y={0} width={140} height={140} fill="#dfe6ff" stroke={OUT} strokeWidth={6} /><Chip x={0} y={60} s={0.35} glow={false} /></g>
      <Stickman look="chris" x={200} y={700} scale={1.5} pose="armsUp" motion="cheer" expr="laugh" seed={1} />
      <Stickman look="jensenYoung" x={lerp(520, 1380, t)} y={700 - 360 * Math.sin(t * Math.PI)} scale={1.7} pose="armsUp" expr="determined" />
      <Stickman look="curtis" x={80} y={700} scale={1.5} flip motion="cheer" expr="laugh" seed={2} />
    </g>
  );
};

const LateNight: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={2} />
      <Calendar x={1380} y={380} s={1.5} />
      <Clock x={1700} y={360} s={1.3} speed={3} />
      <Desk x={760} w={560} />
      <Monitor x={760} y={650} w={300} h={190}>
        {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={14} y={18 + i * 26} width={70 + ((i * 61) % 150)} height={9} rx={4} fill={C.green} />)}
      </Monitor>
      <Mug x={1010} y={760} s={0.8} />
      <Mug x={540} y={760} s={0.8} />
      <rect x={300} y={760} width={150} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
      <Stickman look="jensenYoung" x={375} y={895} scale={1.7} pose="sit" motion="type" expr={f % 80 < 40 ? 'determined' : 'worried'} />
    </g>
  );
};

const Handshake: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgSunrise p={p} />
      <Stickman look="chris" x={620} y={900} scale={1.9} pose="reach" expr="happy" seed={1} />
      <Stickman look="curtis" x={1300} y={900} scale={1.9} pose="reach" flip expr="happy" seed={2} />
      <Stickman look="jensenYoung" x={960} y={900} scale={1.9} motion="cheer" expr="laugh" />
      <Sparkles x={960} y={500} n={10} spread={420} />
    </g>
  );
};

export const CH3 = [DinerTalk, Napkin, Trio, StartupOffice, HangSign, Vision3D, Pitch, Leap, LateNight, Handshake];
