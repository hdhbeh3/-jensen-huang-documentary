// CHAPTER 4 — The NV1 failure and NVIDIA's difficult early period
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgHills, BgOffice, BgRoom} from '../components/Backgrounds';
import {At, BarChart, Bulb, Card, Clock, Coin, Crate, Cross, Desk, Label, Lightning, Monitor, Mug, Storm, Whiteboard, Chip, Qmark, Sparkles} from '../components/Props';
import {C, OUT} from '../theme';
import {lerp, tween, wob, rand} from '../lib/anim';

const Reveal: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <path d="M960 -40 L620 880 H1300Z" fill="#fff6c8" opacity={0.3} />
      <Desk x={960} w={460} />
      <Card x={960} y={740} s={0.9} label="NV1" />
      <Stickman look="chris" x={500} y={900} scale={1.9} motion="cheer" expr="laugh" seed={1} />
      <Stickman look="jensenYoung" x={1400} y={900} scale={1.9} flip pose="armsOpen" expr="happy" />
      <Stickman look="curtis" x={1720} y={900} scale={1.8} flip motion="cheer" expr="laugh" seed={2} />
      <Sparkles x={960} y={640} n={8} spread={300} />
    </g>
  );
};

const Unsold: React.FC = () => {
  const {p} = useP();
  const rows = [[0, 1, 2, 3, 4], [0, 1, 2, 3], [0, 1, 2], [0, 1]];
  return (
    <g>
      <BgOffice p={p} tone={2} />
      {rows.map((r, ri) =>
        r.map((c) => <Crate key={`${ri}${c}`} x={1000 + c * 120 + ri * 60} y={840 - ri * 120} s={0.95} label="NV1" delay={ri * 8 + c * 3 + 6} />),
      )}
      <Stickman look="jensenYoung" x={540} y={900} scale={2.0} pose="slump" expr="sad" />
    </g>
  );
};

const Mismatch: React.FC = () => {
  const {f, p} = useP();
  const bounce = Math.abs(Math.sin(f * 0.12)) * 60;
  return (
    <g>
      <BgRoom p={p} tone={0} wall="#e9e2ff" />
      <g transform="translate(1200 600)">
        <rect x={-200} y={-200} width={400} height={400} rx={16} fill="#c9a37a" stroke={OUT} strokeWidth={8} />
        <rect x={-90} y={-90} width={180} height={180} fill="#3a3f5c" stroke={OUT} strokeWidth={6} />
        <circle cx={-360 + wob(f, 0.25, 8)} cy={-bounce} r={80} fill={C.green} stroke={OUT} strokeWidth={7} />
      </g>
      <Cross x={1200} y={560} s={1.6} delay={30} />
      <Stickman look="jensenYoung" x={420} y={900} scale={2.0} pose="think" expr="worried" />
      <Qmark x={700} y={360} s={0.9} delay={12} />
    </g>
  );
};

const NoDeal: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <Stickman look="engineer" x={620} y={900} scale={1.85} pose="shrug" motion="nod" expr="neutral" seed={1} />
      <Stickman look="engineer2" x={1000} y={900} scale={1.85} pose="shrug" expr="worried" seed={2} />
      <Stickman look="researcher" x={1380} y={900} scale={1.85} flip pose="shrug" motion="nod" expr="neutral" seed={3} />
      {[620, 1000, 1380].map((x, i) => (
        <g key={x}>
          <Crate x={x} y={430} s={0.8} label="GAME" delay={6 + i * 8} />
          <Cross x={x} y={430} s={1.1} delay={24 + i * 8} />
        </g>
      ))}
      <Stickman look="jensenYoung" x={1730} y={900} scale={1.9} flip pose="slump" expr="sad" seed={4} />
    </g>
  );
};

const Falling: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={2} />
      <BarChart x={1250} y={800} s={1.25} values={[1, 0.85, 0.65, 0.5, 0.32, 0.15]} fall />
      {Array.from({length: 6}).map((_, i) => <Coin key={i} x={1000 + i * 90} y={((f * 6 + i * 120) % 900) + 80} s={0.8} />)}
      <Stickman look="jensenYoung" x={470} y={900} scale={2.0} pose="shrug" expr="worried" />
    </g>
  );
};

const EmptyDesks: React.FC = () => {
  const {f, p} = useP();
  const x = lerp(700, 2100, tween(f, 0, 120, 0, 1, (t) => t));
  return (
    <g>
      <BgOffice p={p} tone={2} />
      {[420, 960, 1500].map((dx) => (
        <g key={dx}>
          <Desk x={dx} w={400} />
          <Monitor x={dx} y={650} w={260} h={170} s={0.95} screen="#1b2040" />
        </g>
      ))}
      <Stickman look="engineer" x={x} y={900} scale={1.8} motion="walk" pose="carry" expr="sad" seed={2} />
      <Crate x={x + 10} y={700} s={0.7} />
      <Stickman look="jensenYoung" x={260} y={900} scale={2.0} pose="slump" expr="sad" lookDir={[1, 0]} />
    </g>
  );
};

const RainyNight: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#2b2f5a" />
      {Array.from({length: 40}).map((_, i) => <line key={i} x1={1250 + (i * 9) % 360} y1={170 + ((f * 14 + i * 37) % 300)} x2={1244 + (i * 9) % 360} y2={192 + ((f * 14 + i * 37) % 300)} stroke="#9fd8ff" strokeWidth={3} opacity={0.7} />)}
      <Clock x={560} y={300} s={1.2} speed={4} />
      <Desk x={1000} w={520} />
      <Mug x={1180} y={760} s={0.9} />
      <rect x={520} y={760} width={150} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
      <Stickman look="jensenYoung" x={600} y={895} scale={1.8} pose={['sit', 'sit']} expr={f % 90 < 45 ? 'worried' : 'determined'} lookDir={[1, 0.3]} />
      <path d="M990 770 H1060 V640" stroke={OUT} strokeWidth={8} fill="none" />
      <path d="M1000 640 L1060 600 L1100 640Z" fill={C.yellow} stroke={OUT} strokeWidth={5} />
    </g>
  );
};

const Pivot: React.FC = () => {
  const {f, p} = useP();
  const d = tween(f, 34, 70, 0, 1);
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <Whiteboard x={1100} y={480} w={820} h={470}>
        <g opacity={1 - d * 0.7}><Chip x={-190} y={0} s={0.9} glow={false} label="NV1" /></g>
        <Cross x={-190} y={0} s={2} delay={14} />
        <g transform="translate(200 0)" opacity={d}><Chip x={0} y={0} s={0.9} glow label="NEW" /></g>
      </Whiteboard>
      <Stickman look="jensenYoung" x={400} y={900} scale={2.0} pose="point" motion="talk" expr="determined" speaking />
      <Bulb x={560} y={280} s={0.8} delay={40} />
    </g>
  );
};

const StormClears: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgHills p={p} tone={0} />
      <circle cx={1450} cy={lerp(520, 240, p)} r={120} fill="#ffd36b" opacity={0.95} />
      <Storm x={lerp(900, -400, p)} y={200} s={2.2} />
      <Lightning x={lerp(900, -300, p)} y={300} s={1.4} />
      <g stroke={OUT} strokeWidth={6}><rect x={1100} y={640} width={300} height={250} fill="#dfe6ff" /><rect x={1180} y={760} width={70} height={130} fill="#6a4128" /></g>
      <Stickman look="jensenYoung" x={760} y={900} scale={1.9} pose="hips" expr="determined" lookDir={[1, -0.6]} />
    </g>
  );
};

const AllIn: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={2} />
      <rect x={380} y={730} width={1160} height={34} rx={10} fill="#2f8f5a" stroke={OUT} strokeWidth={7} />
      <rect x={440} y={764} width={30} height={140} fill="#3a3f5c" stroke={OUT} strokeWidth={6} />
      <rect x={1450} y={764} width={30} height={140} fill="#3a3f5c" stroke={OUT} strokeWidth={6} />
      {Array.from({length: 9}).map((_, i) => <Coin key={i} x={900 + (i % 3) * 80 + lerp(0, 160, tween(f, 8, 40, 0, 1))} y={700 - Math.floor(i / 3) * 22} s={0.9} />)}
      <Stickman look="jensenYoung" x={560} y={900} scale={1.95} pose="reach" expr="determined" />
      <Stickman look="chris" x={1500} y={900} scale={1.85} flip pose="cross" expr="worried" seed={2} />
      <Stickman look="curtis" x={1780} y={900} scale={1.8} flip pose="cross" expr="worried" seed={3} />
    </g>
  );
};

export const CH4 = [Reveal, Unsold, Mismatch, NoDeal, Falling, EmptyDesks, RainyNight, Pivot, StormClears, AllIn];
