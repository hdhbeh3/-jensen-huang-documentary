// CHAPTER 5 — RIVA 128 and the rise of GPU technology
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {BgBlueprint, BgCity, BgOffice, BgRoom, BgStage, BgSunrise} from '../components/Backgrounds';
import {At, Bell, BarChart, Calendar, Car, Card, Clock, Coin, Confetti, Crate, Desk, Label, Monitor, Sparkles} from '../components/Props';
import {Workstation} from './ch3';
import {C, OUT} from '../theme';
import {lerp, pop, rand, tween} from '../lib/anim';

const CurtainReveal: React.FC = () => {
  const {f, p} = useP();
  const open = tween(f, 10, 50, 0, 1);
  return (
    <g>
      <BgStage p={p} />
      <g transform="translate(960 640)"><ellipse cy={140} rx={260} ry={36} fill="#2b2f4a" stroke={C.green} strokeWidth={6} /></g>
      <Card x={960} y={620} s={1.2} label="RIVA 128" />
      <Sparkles x={960} y={560} n={10} spread={380} color={C.green} />
      <rect x={-20 - open * 960} y={-30} width={1000} height={920} fill="#9c2f3f" stroke={OUT} strokeWidth={8} />
      <rect x={940 + open * 960} y={-30} width={1000} height={920} fill="#9c2f3f" stroke={OUT} strokeWidth={8} />
      <Stickman look="jensenYoung" x={420} y={900} scale={1.9} pose="point" expr="happy" />
    </g>
  );
};

const Crunch: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={3} />
      <Workstation x={480} look="chris" seed={4} />
      <Workstation x={1000} look="jensenYoung" seed={5} />
      <Workstation x={1520} look="curtis" seed={6} />
      <Calendar x={960} y={260} s={1.2} />
      <Clock x={1230} y={250} s={1.1} speed={8} />
    </g>
  );
};

const Benchmark: React.FC = () => {
  const {f, p} = useP();
  const bars: [number, number][] = [[0.35, 0.5], [0.45, 0.8], [0.5, 1]];
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <rect x={760} y={180} width={1000} height={620} rx={18} fill="#fffaf0" stroke={OUT} strokeWidth={7} />
      {bars.map(([a, b], i) => {
        const ka = tween(f, i * 8, i * 8 + 34, 0, 1), kb = tween(f, i * 8 + 10, i * 8 + 50, 0, 1);
        return (
          <g key={i}>
            <rect x={840 + i * 300} y={760 - 480 * a * ka} width={90} height={480 * a * ka} rx={8} fill={C.gray} stroke={OUT} strokeWidth={6} />
            <rect x={940 + i * 300} y={760 - 480 * b * kb} width={90} height={480 * b * kb} rx={8} fill={C.green} stroke={OUT} strokeWidth={6} />
          </g>
        );
      })}
      <Stickman look="jensenYoung" x={400} y={900} scale={2.0} pose="point" motion="talk" expr="happy" speaking />
    </g>
  );
};

const SmoothGame: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#323876" />
      <Monitor x={960} y={470} w={700} h={430}>
        <rect x={0} y={0} width={672} height={402} fill="#6fc3ff" />
        <path d={`M0 240 H672 V402 H0Z`} fill="#4a4f66" />
        {Array.from({length: 7}).map((_, i) => <rect key={i} x={((i * 120 - f * 14) % 840 + 840) % 840 - 80} y={316} width={70} height={12} fill="#fff" />)}
        <At x={330} y={250} s={0.9}><Car x={0} y={0} /></At>
      </Monitor>
      <Stickman look="gamer" x={420} y={900} scale={1.85} motion="cheer" expr="laugh" seed={1} />
      <Stickman look="gamer2" x={1500} y={900} scale={1.85} flip motion="cheer" expr="laugh" seed={2} />
    </g>
  );
};

const Orders: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={3} />
      <rect x={-100} y={760} width={2200} height={50} fill="#4a4f66" stroke={OUT} strokeWidth={7} />
      {Array.from({length: 6}).map((_, i) => <Crate key={i} x={((i * 340 + f * 8) % 2200) - 150} y={700} s={0.85} label="RIVA" />)}
      {Array.from({length: 7}).map((_, i) => <Coin key={i} x={150 + i * 290} y={320 - Math.abs(Math.sin(f * 0.14 + i)) * 40} delay={i * 4} />)}
      <Stickman look="engineer" x={500} y={900} scale={1.8} motion="wave" expr="happy" seed={1} />
      <Stickman look="jensenYoung" x={1400} y={900} scale={1.95} flip pose="armsUp" expr="laugh" />
    </g>
  );
};

const Relief: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgSunrise p={p} />
      <Stickman look="chris" x={640} y={900} scale={1.9} pose="both" expr="laugh" seed={1} />
      <Stickman look="jensenYoung" x={960} y={900} scale={2} motion="cheer" expr="laugh" />
      <Stickman look="curtis" x={1280} y={900} scale={1.9} flip pose="both" expr="laugh" seed={2} />
      <Confetti n={60} />
    </g>
  );
};

const ManyCores: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgBlueprint p={p} />
      <g transform="translate(520 500)">
        <rect x={-170} y={-170} width={340} height={340} rx={20} fill="#2a3158" stroke={OUT} strokeWidth={7} />
        <rect x={-90} y={-90} width={180} height={180} rx={10} fill={f % 40 < 20 ? C.orange : '#c97a2a'} stroke={OUT} strokeWidth={6} />
        <Label y={250} size={44}>CPU</Label>
      </g>
      <g transform="translate(1340 500)">
        <rect x={-210} y={-210} width={420} height={420} rx={20} fill="#2a3158" stroke={OUT} strokeWidth={7} />
        {Array.from({length: 64}).map((_, i) => {
          const cx = i % 8, cy = Math.floor(i / 8);
          const on = Math.sin(f * 0.25 - (cx + cy) * 0.6) > -0.2;
          return <rect key={i} x={-180 + cx * 46} y={-180 + cy * 46} width={34} height={34} rx={5} fill={on ? C.green : '#2d4a22'} stroke={OUT} strokeWidth={3} />;
        })}
        <Label y={290} size={44} color={C.green}>GPU</Label>
      </g>
      <Stickman look="jensenYoung" x={960} y={900} scale={1.8} pose="armsOpen" motion="talk" expr="happy" speaking />
    </g>
  );
};

const Listing: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgCity p={p} tone={0} />
      <rect x={600} y={150} width={720} height={420} rx={20} fill="#10152f" stroke={C.green} strokeWidth={8} />
      <path d="M650 500 L780 420 L880 460 L1000 330 L1110 380 L1270 220" stroke={C.green} strokeWidth={12} fill="none" strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - tween(f, 4, 60, 0, 1)} />
      <Bell x={1500} y={430} s={1.5} />
      <Stickman look="jensenYoung" x={1400} y={900} scale={2.0} pose="pointUp" expr="laugh" flip />
      <Stickman look="chris" x={540} y={900} scale={1.85} motion="cheer" expr="laugh" seed={2} />
      <Confetti n={40} />
    </g>
  );
};

const LanParty: React.FC = () => {
  const {f, p} = useP();
  const looks = ['gamer', 'gamer2', 'student2'] as const;
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#2d3270" />
      {looks.map((l, i) => {
        const x = 480 + i * 480;
        return (
          <g key={l}>
            <Desk x={x + 120} w={340} />
            <Monitor x={x + 120} y={650} w={240} h={150} s={0.95}>
              <rect x={0} y={0} width={212} height={122} fill={['#3a1d5a', '#1d4a5a', '#5a2a1d'][i]} />
              <circle cx={106 + Math.sin(f * 0.15 + i) * 60} cy={60} r={16} fill={C.green} />
            </Monitor>
            <Stickman look={l} x={x - 80} y={895} scale={1.5} pose="sit" motion="work" expr={f % 70 < 35 ? 'determined' : 'laugh'} seed={i} />
          </g>
        );
      })}
    </g>
  );
};

const MoveForward: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgCity p={p} tone={3} />
      <Stickman look="jensenYoung" x={lerp(300, 1500, p)} y={900} scale={2.0} motion="walk" pose="hold" expr="determined" />
      <Card x={lerp(300, 1500, p) + 20} y={650} s={0.45} label="RIVA" spin />
    </g>
  );
};

export const CH5 = [CurtainReveal, Crunch, Benchmark, SmoothGame, Orders, Relief, ManyCores, Listing, LanParty, MoveForward];
