// CHAPTER 1 — Opening hook: NVIDIA's global impact
import React from 'react';
import {useP} from '../components/context';
import {Stickman} from '../components/Stickman';
import {Crowd} from '../components/Crowd';
import {BgBlueprint, BgCity, BgDatacenter, BgGlow, BgOffice, BgRoom, BgStage} from '../components/Backgrounds';
import {At, BarChart, Car, Chip, Coin, Desk, Globe, Laptop, Monitor, Phone, Podium, Qmark, Rack3, Ripple, Robot, Sparkles, Trophy, ChatUI, Card, Banner} from '../components/Props';
import {C, OUT} from '../theme';
import {pop, rand, tween} from '../lib/anim';

const orbit = (f: number, i: number, n: number, rx: number, ry: number, speed = 0.02) => {
  const a = f * speed + (i / n) * Math.PI * 2;
  return {x: 960 + Math.cos(a) * rx, y: 540 + Math.sin(a) * ry, depth: Math.sin(a)};
};

const GlobeShot: React.FC = () => {
  const {f, p} = useP();
  const items = [Phone, Car, Robot, Laptop, Chip, Card];
  return (
    <g>
      <BgGlow p={p} />
      <Ripple x={960} y={540} max={800} />
      <Globe x={960} y={540} r={240} />
      {items.map((I, i) => {
        const o = orbit(f, i, items.length, 560, 260);
        return <I key={i} x={o.x} y={o.y} s={0.45 + 0.12 * o.depth} />;
      })}
    </g>
  );
};

const CityIcons: React.FC = () => {
  const {f, p, v} = useP();
  const icons = [Phone, Laptop, Car, Robot, Chip];
  return (
    <g>
      <BgCity p={p} tone={v % 2 === 0 ? 2 : 1} />
      {icons.map((I, i) => {
        const y = 760 - ((f * 3.2 + i * 230) % 900);
        return <I key={i} x={220 + i * 370} y={y + 300} s={0.55} />;
      })}
      <Sparkles x={960} y={300} n={10} spread={500} color="#fff" />
    </g>
  );
};

const GamerRoom: React.FC = () => {
  const {f, p, v} = useP();
  return (
    <g>
      <BgRoom p={p} tone={2} wall="#3a3f7a" />
      <Desk x={1130} w={560} />
      <Monitor x={1130} y={620} w={380} h={230}>
        <rect x={0} y={0} width={352} height={202} fill="#162a52" />
        <path d="M0 150 Q80 90 170 130 T352 100 V202 H0Z" fill="#3fae5a" />
        <circle cx={260 - (f * 2) % 200} cy={50} r={24} fill={C.yellow} />
        <At x={120 + Math.sin(f * 0.2) * 40} y={110} s={0.35}><Car x={0} y={0} /></At>
      </Monitor>
      <Card x={1320} y={738} s={0.35} />
      <rect x={560} y={740} width={170} height={20} rx={8} fill="#2b2f4a" stroke={OUT} strokeWidth={6} />
      <Stickman look={v % 2 ? 'gamer2' : 'gamer'} x={730} y={895} scale={1.65} pose="hold" expr={f % 60 < 30 ? 'determined' : 'laugh'} />
      <Sparkles x={1130} y={500} n={6} spread={260} color={C.green} />
    </g>
  );
};

const Datacenter: React.FC = () => {
  const {p} = useP();
  return (
    <g>
      <BgDatacenter p={p} />
      <Stickman look="researcher" x={300 + p * 1300} y={900} scale={1.7} motion="walk" pose="idle" expr="surprised" />
      <Rack3 x={1700} y={680} s={1.2} />
    </g>
  );
};

const ChipZoom: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgGlow p={p} />
      {Array.from({length: 16}).map((_, i) => {
        const a = (i / 16) * Math.PI * 2;
        const L = 300 + ((f * 6 + i * 50) % 500);
        return <line key={i} x1={960 + Math.cos(a) * 220} y1={540 + Math.sin(a) * 220} x2={960 + Math.cos(a) * L} y2={540 + Math.sin(a) * L} stroke={C.greenGlow} strokeWidth={4} opacity={0.5} strokeLinecap="round" />;
      })}
      <Chip x={960} y={540} s={2.1} />
    </g>
  );
};

const GrowthChart: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgOffice p={p} tone={0} />
      <BarChart x={1250} y={800} s={1.25} />
      <Trophy x={1700} y={780} s={1.2} />
      {[0, 1, 2, 3, 4].map((i) => <Coin key={i} x={1000 + i * 120} y={250 - Math.abs(Math.sin(f * 0.15 + i)) * 40} delay={20 + i * 5} />)}
      <Stickman look="jensenCEO" x={430} y={900} scale={1.8} pose="point" motion="talk" expr="happy" speaking />
    </g>
  );
};

const KeynoteStage: React.FC = () => {
  const {f, p, v} = useP();
  return (
    <g>
      <BgStage p={p} />
      <Podium x={1260} y={760} s={1.1} />
      <Stickman look="jensenCEO" x={820} y={880} scale={1.9} pose="armsOpen" motion="talk" expr="happy" speaking />
      <Chip x={1500} y={330} s={0.9} />
      <Crowd phones={v % 2 === 1} cheer={0.5} />
    </g>
  );
};

const WhoIsHe: React.FC = () => {
  const {f, p} = useP();
  return (
    <g>
      <BgCity p={p} tone={3} />
      <path d="M960 -40 L560 900 H1360Z" fill="#fff6c8" opacity={0.22} />
      <Stickman look="jensenCEO" x={960} y={900} scale={2} pose="think" expr="thinking" />
      {[0, 1, 2, 3].map((i) => <Qmark key={i} x={540 + i * 280} y={300 + (i % 2) * 120 + Math.sin(f * 0.1 + i) * 14} s={0.8} delay={8 + i * 6} />)}
    </g>
  );
};

const AIEverywhere: React.FC = () => {
  const {f, p} = useP();
  const items = [Robot, Car, ChatUI, Phone, Laptop];
  return (
    <g>
      <BgBlueprint p={p} />
      <Chip x={960} y={540} s={1.1} />
      {items.map((I, i) => {
        const o = orbit(f, i, items.length, 640, 280, -0.016);
        return <I key={i} x={o.x} y={o.y} s={(I === ChatUI ? 0.3 : 0.7) + 0.1 * o.depth} />;
      })}
    </g>
  );
};

export const CH1 = [GlobeShot, CityIcons, GamerRoom, Datacenter, ChipZoom, GrowthChart, KeynoteStage, WhoIsHe, AIEverywhere];
