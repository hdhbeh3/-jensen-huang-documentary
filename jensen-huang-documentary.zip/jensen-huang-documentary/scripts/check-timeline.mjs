// Sanity-check the shot timeline without rendering: node scripts/check-timeline.mjs
// Re-implements src/timeline.ts's planning so it can run with plain Node.
import fs from 'node:fs';
const timing = JSON.parse(fs.readFileSync(new URL('../src/data/timing.json', import.meta.url)));
const src = fs.readFileSync(new URL('../src/data/chapters.ts', import.meta.url), 'utf8');
const startPhrases = [...src.matchAll(/startPhrase: (\d+)/g)].map((m) => +m[1]);
const libSizes = [...fs.readdirSync(new URL('../src/shots/', import.meta.url))].sort().map((f) => {
  const t = fs.readFileSync(new URL(`../src/shots/${f}`, import.meta.url), 'utf8');
  const m = t.match(/export const CH\d = \[([^\]]*)\]/);
  return m[1].split(',').filter((s) => s.trim()).length;
});
const FPS = timing.fps, TOTAL = timing.durationInFrames, ph = timing.phrases;
const T = 2.6, MIN = 30;
const chapters = startPhrases.map((s, i) => ({from: i === 0 ? 0 : Math.round(ph[s].start * FPS)}));
chapters.forEach((c, i) => (c.to = i === chapters.length - 1 ? TOTAL : chapters[i + 1].from));
let all = [];
chapters.forEach((ch, ci) => {
  const cuts = [ch.from];
  ph.forEach((p) => { const fr = Math.round(p.start * FPS); if (fr > ch.from + MIN && fr < ch.to - MIN) cuts.push(fr); });
  cuts.push(ch.to);
  let k = 0;
  for (let i = 0; i < cuts.length - 1; i++) {
    const a = cuts[i], b = cuts[i + 1], n = Math.max(1, Math.round((b - a) / (T * FPS)));
    for (let j = 0; j < n; j++) {
      const s = a + Math.round(((b - a) * j) / n), e = a + Math.round(((b - a) * (j + 1)) / n);
      all.push({from: s, dur: e - s, ci, k}); k++;
    }
  }
});
let ok = true, cursor = 0;
for (const s of all) { if (s.from !== cursor || s.dur <= 0) { ok = false; console.log('GAP/ORDER problem at', s); } cursor = s.from + s.dur; }
if (cursor !== TOTAL) { ok = false; console.log('Total mismatch', cursor, TOTAL); }
const durs = all.map((s) => s.dur / FPS);
console.log('shots:', all.length, 'min/avg/max sec:', Math.min(...durs).toFixed(2), (durs.reduce((a, b) => a + b) / durs.length).toFixed(2), Math.max(...durs).toFixed(2));
chapters.forEach((c, i) => { const n = all.filter((s) => s.ci === i).length; console.log(`ch${i + 1}: ${(c.from / FPS).toFixed(1)}s–${(c.to / FPS).toFixed(1)}s, ${n} shots from ${libSizes[i]} templates (each reused ~${(n / libSizes[i]).toFixed(1)}x)`); });
console.log(ok ? 'TIMELINE OK: contiguous, covers every frame of the narration' : 'TIMELINE PROBLEM');
process.exit(ok ? 0 : 1);
