#!/usr/bin/env python3
"""Measure public/narration.wav and write src/data/timing.json.

Outputs: exact duration, pause-delimited "phrases" (natural cut points) and a
per-frame loudness envelope (24 fps) used for mouth movement.
Requires: ffmpeg + numpy.  Usage: python3 scripts/analyze-audio.py [fps]
"""
import json, re, subprocess, sys, wave
import numpy as np

FPS = int(sys.argv[1]) if len(sys.argv) > 1 else 24
SRC = "public/narration.wav"

with wave.open(SRC) as w:
    sr, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
    raw = w.readframes(n)
duration = n / sr
x = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
if ch > 1:
    x = x.reshape(-1, ch).mean(axis=1)

# --- pauses via ffmpeg silencedetect
out = subprocess.run(
    ["ffmpeg", "-hide_banner", "-i", SRC, "-af", "silencedetect=noise=-40dB:d=0.7", "-f", "null", "-"],
    capture_output=True, text=True).stderr
starts = [float(m) for m in re.findall(r"silence_start: ([\d.]+)", out)]
ends = [float(m) for m in re.findall(r"silence_end: ([\d.]+)", out)]
pauses = list(zip(starts, ends))
# phrase boundaries sit in the middle of each pause
cuts = [0.0] + [round((a + b) / 2, 3) for a, b in pauses] + [round(duration, 3)]
phrases = [{"start": cuts[i], "end": cuts[i + 1]} for i in range(len(cuts) - 1) if cuts[i + 1] - cuts[i] > 0.3]

# --- per-frame envelope (RMS, normalised, smoothed)
spf = sr / FPS
frames = int(np.ceil(duration * FPS))
env = np.zeros(frames, dtype=np.float32)
for f in range(frames):
    seg = x[int(f * spf): int((f + 1) * spf)]
    env[f] = np.sqrt(np.mean(seg ** 2)) if len(seg) else 0
env = env / (np.percentile(env, 95) + 1e-9)
env = np.clip(env, 0, 1)
env = np.convolve(env, np.ones(2) / 2, mode="same")

json.dump({
    "fps": FPS,
    "durationSeconds": round(duration, 3),
    "durationInFrames": frames,
    "phrases": phrases,
    "envelope": [round(float(v), 2) for v in env],
}, open("src/data/timing.json", "w"), separators=(",", ":"))
print(f"duration={duration:.2f}s frames={frames} phrases={len(phrases)}")
