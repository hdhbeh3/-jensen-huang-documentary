# Jensen Huang — The Man Behind NVIDIA (Remotion project)

2D illustrated documentary animation, 1920×1080 @ 24 fps, synchronised to the approved
narration (`public/narration.wav`, 9:41.74 = 13,962 frames). The narration is used as-is.

## ⚠️ Read this first — status and honest caveats

| Item | Status |
|---|---|
| Audio duration / frame count (13,962 @ 24 fps) | **Measured** from the WAV |
| 85 phrase boundaries (pauses) | **Measured** with ffmpeg `silencedetect` |
| Every shot cut lands on the real audio timeline (no gaps, covers every frame) | **Verified** with `npm run check-timeline` |
| TypeScript syntax / names / props | **Checked** with `tsc` against stubbed React + Remotion types |
| Actual Remotion render, Studio preview, visual quality, GitHub Actions run | **NOT tested** (no network in the build sandbox, so Remotion could not be installed) |
| Chapter start times | **Estimated** — the narration *content* could not be transcribed |

**What that means:** the chapter boundaries (which story section plays when) were placed by
proportion and snapped to the nearest pause. The visuals are chronologically correct, but
they may not line up with what the voice is saying at that moment. Fix this in two minutes:

1. `npm run studio`, scrub to where each topic really begins in the narration.
2. Edit `startPhrase` (or set exact `startSecond`) per chapter in `src/data/chapters.ts`.

Expect to fix small visual bugs on first preview (positions, overlaps) — it has never been rendered.

## Quick start

```bash
npm install
npm run studio            # live preview / scrubbing
npm run render:preview    # first 20 s at half size -> out/preview.mp4
npm run render            # full film -> out/jensen-huang-documentary.mp4
npm run check-timeline    # verify cuts cover the whole narration
```
Requires Node 18+ (20 recommended). Remotion downloads its own Chrome on first render.
Full-quality render is long (13,962 frames of SVG); expect roughly 30–90 min depending on CPU.

## Rendering on GitHub Actions

Push the project to a GitHub repo, open **Actions → Render documentary → Run workflow**.
- Leave *frames* empty for the full film, or e.g. `0-479` with *scale* `0.5` for a quick preview.
- The MP4 appears as the `jensen-huang-documentary` artifact (kept 14 days).
- Pushing a tag like `v1.0` also triggers a full render.
The workflow is `.github/workflows/render.yml` (installs Chrome libraries, `npm install`, type-checks, renders).
`public/narration.wav` is ~28 MB — below GitHub's 100 MB file limit, no LFS needed.
No `package-lock.json` is included (could not be generated offline); run `npm install` once and commit it
for reproducible builds.

## How it is organised

```
public/narration.wav            approved voiceover (untouched)
scripts/analyze-audio.py        re-measures the audio -> src/data/timing.json
scripts/check-timeline.mjs      sanity check of the shot plan
src/
  data/timing.json              duration, phrase boundaries, loudness envelope
  data/chapters.ts              the 8 chapters + their start points  <-- edit boundaries here
  timeline.ts                   turns phrases into shots (target ~2.6 s, always cut on a pause)
  Documentary.tsx               audio + shots + camera + chapter cards + fades
  theme.ts                      palette, outline weight, sizes
  components/
    Stickman.tsx, looks.ts      the character rig: 5 Jensen looks (child, teen, young, CEO, diner worker) + 18 supporting looks,
                                8 expressions, 17 poses, walk/wave/talk/type/cheer motions
    Backgrounds.tsx             15 reusable backgrounds, 4 times of day (tone 0–3)
    Props.tsx                   ~50 props (chips, cards, charts, globe, neural net, ...)
    Crowd.tsx, Camera.tsx, Overlays.tsx, context.tsx
  shots/ch1.tsx … ch8.tsx       the scene library (one file per chapter, 9–12 shots each)
```

### How sync works
`scripts/analyze-audio.py` finds the pauses in the narration (85 phrases). `timeline.ts` places a cut
at the start of each phrase and splits long phrases evenly into shots of about 2.6 s
(measured: min 1.96 s, avg 2.60 s, max 3.83 s; 224 shots). A chapter's shots cycle through its template library;
on each repeat the *tone* (day / sunset / night / dawn) and the camera move change.
Characters' mouths follow the real loudness envelope when `speaking` is set.
If you replace the audio, run `npm run analyze-audio` and re-check chapter starts.

### Editing
- New shot: add a component to `src/shots/chN.tsx` and append it to that file's export array.
- New character: add a `Look` in `components/looks.ts`.
- Jensen's look per age: `jensenChild`, `jensenTeen`, `jensenYoung`, `jensenCEO` (black leather jacket, glasses, side-swept hair).
- Stage is a 1920×1080 SVG; the floor line is y = 900.

## Known limits
- Template reuse: chapters reuse their 9–12 shot templates about 2–4 times (varied by tone and camera). Add shots for more variety.
- The sandbox could not transcribe the audio, so no captions/subtitles are generated and scene content is matched to the story order, not to individual sentences.
- Text on screen is limited to name tags, product names (NV1, RIVA 128, GeForce 256, CUDA, AlexNet) and chapter titles. No NVIDIA logo or third-party footage/music is used.
- Historical details drawn (diner meeting, NV1 console deal, chores, table tennis, AlexNet's two GPUs, etc.) come from general knowledge; check them against your script.
